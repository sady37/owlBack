--
-- PostgreSQL database dump
--

\restrict fHKF4WJpX0gNBjnBP4SZGesWe9nenpNAxm4xYQxglVcs5xrsCBA6jYWhFYnbs1M

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.15 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: allocate_device_to_tenant(uuid, uuid, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_device_to_tenant(p_device_store_id uuid, p_tenant_id uuid, p_allow_access boolean DEFAULT true) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_current_tenant_id UUID;
BEGIN
    -- 检查设备是否存在
    SELECT tenant_id INTO v_current_tenant_id
    FROM device_store
    WHERE device_store_id = p_device_store_id;
    
    IF v_current_tenant_id IS NULL THEN
        RAISE EXCEPTION 'Device not found: %', p_device_store_id;
    END IF;
    
    -- 检查设备是否已分配
    IF v_current_tenant_id != '00000000-0000-0000-0000-000000000000' THEN
        RAISE EXCEPTION 'Device already allocated to tenant: %', v_current_tenant_id;
    END IF;
    
    -- Update tenant ID, allocation time and system level permission
    UPDATE device_store
    SET tenant_id = p_tenant_id,
        allocate_time = CURRENT_TIMESTAMP,
        allow_access = p_allow_access
    WHERE device_store_id = p_device_store_id;
    
    RETURN TRUE;
END;
$$;


--
-- Name: FUNCTION allocate_device_to_tenant(p_device_store_id uuid, p_tenant_id uuid, p_allow_access boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.allocate_device_to_tenant(p_device_store_id uuid, p_tenant_id uuid, p_allow_access boolean) IS '分配设备给租户（系统管理员操作）：更新 tenant_id、allocate_time 和 allow_access。如果设备已分配，会报错。仅限系统管理员使用';


--
-- Name: ensure_lowercase_resident_account(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ensure_lowercase_resident_account() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.resident_account := LOWER(NEW.resident_account);
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION ensure_lowercase_resident_account(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.ensure_lowercase_resident_account() IS '确保 resident_account 在插入或更新时自动转换为小写，方便统一计算 hash';


--
-- Name: ensure_lowercase_user_account(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ensure_lowercase_user_account() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.user_account := LOWER(NEW.user_account);
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION ensure_lowercase_user_account(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.ensure_lowercase_user_account() IS '确保 user_account 在插入或更新时自动转换为小写，方便统一计算 hash';


--
-- Name: get_device_default_monitor_config(uuid, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_device_default_monitor_config(p_tenant_id uuid, p_device_type character varying, p_device_model character varying DEFAULT NULL::character varying) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_cloud_config JSONB;
    v_default_config JSONB := '{"alarms": {}, "sleep_period": null}'::jsonb;
    v_alarm_key TEXT;
    v_alarm_level TEXT;
BEGIN
    -- 获取 alarm_cloud 中的配置（支持租户覆盖）
    -- 注意：新设计中不再支持设备型号级别覆盖，一个租户只有一条记录，包含所有设备类型的配置
    SELECT get_device_type_alarm_config(p_tenant_id, p_device_type) INTO v_cloud_config;
    
    IF v_cloud_config IS NULL OR v_cloud_config = '{}'::jsonb THEN
        RETURN v_default_config;
    END IF;
    
    -- 构建默认配置结构
    -- 添加通用报警
    IF v_cloud_config->>'OfflineAlarm' IS NOT NULL THEN
        v_default_config := jsonb_set(
            v_default_config,
            ARRAY['alarms', 'OfflineAlarm'],
            jsonb_build_object(
                'level', v_cloud_config->>'OfflineAlarm',
                'enabled', (v_cloud_config->>'OfflineAlarm' != 'DISABLE')
            )
        );
    END IF;
    
    IF v_cloud_config->>'LowBattery' IS NOT NULL THEN
        v_default_config := jsonb_set(
            v_default_config,
            ARRAY['alarms', 'LowBattery'],
            jsonb_build_object(
                'level', v_cloud_config->>'LowBattery',
                'enabled', (v_cloud_config->>'LowBattery' != 'DISABLE')
            )
        );
    END IF;
    
    IF v_cloud_config->>'DeviceFailure' IS NOT NULL THEN
        v_default_config := jsonb_set(
            v_default_config,
            ARRAY['alarms', 'DeviceFailure'],
            jsonb_build_object(
                'level', v_cloud_config->>'DeviceFailure',
                'enabled', (v_cloud_config->>'DeviceFailure' != 'DISABLE')
            )
        );
    END IF;
    
    -- 添加设备特定报警（从 monitor_json 中获取）
    IF v_cloud_config->'monitor_json' IS NOT NULL THEN
        FOR v_alarm_key, v_alarm_level IN 
            SELECT * FROM jsonb_each_text(v_cloud_config->'monitor_json')
        LOOP
            v_default_config := jsonb_set(
                v_default_config,
                ARRAY['alarms', v_alarm_key],
                jsonb_build_object(
                    'level', v_alarm_level,
                    'enabled', (v_alarm_level != 'DISABLE')
                )
            );
        END LOOP;
    END IF;
    
    RETURN v_default_config;
END;
$$;


--
-- Name: FUNCTION get_device_default_monitor_config(p_tenant_id uuid, p_device_type character varying, p_device_model character varying); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_device_default_monitor_config(p_tenant_id uuid, p_device_type character varying, p_device_model character varying) IS '获取设备类型的默认配置：用于初次配置时的初始值，从 alarm_cloud 获取并构建默认的 monitor_config 结构。支持租户级别覆盖（不再支持设备型号级别覆盖）';


--
-- Name: get_device_type_alarm_config(uuid, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_device_type_alarm_config(p_tenant_id uuid, p_device_type character varying) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_tenant_config RECORD;
    v_system_config RECORD;
    v_device_alarms JSONB;
    v_result JSONB;
BEGIN
    -- 1. 优先查询租户特定配置（tenant_id = p_tenant_id）
    SELECT * INTO v_tenant_config
    FROM alarm_cloud
    WHERE tenant_id = p_tenant_id;
    
    -- 2. 如果租户没有配置，查询系统默认模板（tenant_id = SystemTenantID）
    IF v_tenant_config.tenant_id IS NULL THEN
        SELECT * INTO v_system_config
        FROM alarm_cloud
        WHERE tenant_id = '00000000-0000-0000-0000-000000000001';
    END IF;
    
    -- 3. 获取该设备类型的报警配置（从 device_alarms 中提取）
    v_device_alarms := COALESCE(
        v_tenant_config.device_alarms->p_device_type,
        v_system_config.device_alarms->p_device_type,
        '{}'::jsonb
    );
    
    -- 4. 合并配置：租户配置优先，系统默认作为基础
    v_result := jsonb_build_object(
        'OfflineAlarm', COALESCE(
            v_tenant_config.OfflineAlarm,
            v_system_config.OfflineAlarm
        ),
        'LowBattery', COALESCE(
            v_tenant_config.LowBattery,
            v_system_config.LowBattery
        ),
        'DeviceFailure', COALESCE(
            v_tenant_config.DeviceFailure,
            v_system_config.DeviceFailure
        ),
        'monitor_json', v_device_alarms,  -- 保持向后兼容，使用 monitor_json 作为 key
        'conditions', COALESCE(
            v_tenant_config.conditions,
            v_system_config.conditions
        ),
        'notification_rules', COALESCE(
            v_tenant_config.notification_rules,
            v_system_config.notification_rules
        )
    );
    
    RETURN v_result;
END;
$$;


--
-- Name: FUNCTION get_device_type_alarm_config(p_tenant_id uuid, p_device_type character varying); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_device_type_alarm_config(p_tenant_id uuid, p_device_type character varying) IS '获取设备类型的报警配置：支持租户级别覆盖。匹配优先级：1) 租户特定配置，2) 系统默认配置。从 device_alarms[device_type] 中提取该设备类型的报警配置';


--
-- Name: get_iot_monitor_config(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_iot_monitor_config(p_tenant_id uuid, p_device_id uuid) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_device_config RECORD;
BEGIN
    -- 获取设备配置（必须匹配 tenant_id 和 device_id）
    SELECT * INTO v_device_config
    FROM alarm_device
    WHERE device_id = p_device_id
      AND tenant_id = p_tenant_id;
    
    IF v_device_config.device_id IS NULL THEN
        RETURN '{}'::jsonb;
    END IF;
    
    -- 返回完整配置
    RETURN jsonb_build_object(
        'monitor_config', v_device_config.monitor_config,
        'vendor_config', v_device_config.vendor_config
    );
END;
$$;


--
-- Name: FUNCTION get_iot_monitor_config(p_tenant_id uuid, p_device_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_iot_monitor_config(p_tenant_id uuid, p_device_id uuid) IS '获取设备的完整监控配置：返回 monitor_config 和 vendor_config。必须提供 tenant_id 和 device_id，防止跨租户数据访问';


--
-- Name: get_tenant_devices(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_tenant_devices(p_tenant_id uuid) RETURNS TABLE(device_store_id uuid, device_type character varying, device_model character varying, serial_number character varying, uid character varying, firmware_version character varying, import_date timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ds.device_store_id,
        ds.device_type,
        ds.device_model,
        ds.serial_number,
        ds.uid,
        ds.firmware_version,
        ds.import_date
    FROM device_store ds
    WHERE ds.tenant_id = p_tenant_id
    ORDER BY ds.import_date DESC, ds.device_type, ds.serial_number;
END;
$$;


--
-- Name: FUNCTION get_tenant_devices(p_tenant_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_tenant_devices(p_tenant_id uuid) IS '获取指定租户的设备列表（租户视图，只读）：返回分配给指定租户的所有设备，不显示系统管理员字段（allocate_time、allow_access）。租户只能查看，不能直接操作 device_store';


--
-- Name: get_tenant_devices_admin(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_tenant_devices_admin(p_tenant_id uuid) RETURNS TABLE(device_store_id uuid, device_type character varying, device_model character varying, serial_number character varying, uid character varying, firmware_version character varying, import_date timestamp with time zone, allocate_time timestamp with time zone, allow_access boolean, ota_target_firmware_version character varying, ota_target_mcu_model character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ds.device_store_id,
        ds.device_type,
        ds.device_model,
        ds.serial_number,
        ds.uid,
        ds.firmware_version,
        ds.import_date,
        ds.allocate_time,
        ds.allow_access,
        ds.ota_target_firmware_version,
        ds.ota_target_mcu_model
    FROM device_store ds
    WHERE ds.tenant_id = p_tenant_id
    ORDER BY ds.allocate_time DESC, ds.device_type, ds.serial_number;
END;
$$;


--
-- Name: FUNCTION get_tenant_devices_admin(p_tenant_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_tenant_devices_admin(p_tenant_id uuid) IS '获取指定租户的设备列表（系统管理员视图）：返回分配给指定租户的所有设备，包含所有字段（包括 allocate_time、allow_access、OTA 升级信息）。用于 OTA 升级管理。仅限系统管理员使用';


--
-- Name: get_unassigned_devices(character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_unassigned_devices(p_device_type character varying DEFAULT NULL::character varying) RETURNS TABLE(device_store_id uuid, device_type character varying, device_model character varying, serial_number character varying, uid character varying, firmware_version character varying, import_date timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ds.device_store_id,
        ds.device_type,
        ds.device_model,
        ds.serial_number,
        ds.uid,
        ds.firmware_version,
        ds.import_date
    FROM device_store ds
    WHERE ds.tenant_id = '00000000-0000-0000-0000-000000000000'
      AND (p_device_type IS NULL OR ds.device_type = p_device_type)
    ORDER BY ds.import_date DESC, ds.device_type, ds.serial_number;
END;
$$;


--
-- Name: FUNCTION get_unassigned_devices(p_device_type character varying); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_unassigned_devices(p_device_type character varying) IS '获取未分配的设备列表（系统管理员操作）：返回所有未分配给租户的设备（tenant_id = 默认值）。仅限系统管理员使用';


--
-- Name: is_device_used(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_device_used(p_device_id uuid) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    -- 检查设备是否存在
    IF NOT EXISTS (
        SELECT 1
        FROM devices
        WHERE device_id = p_device_id
    ) THEN
        RAISE EXCEPTION 'Device not found: %', p_device_id;
    END IF;
    
    -- 只需检查是否有监控数据上报
    -- 如果有数据，设备一定已安装、已绑定位置、且曾启用监控
    RETURN EXISTS(
        SELECT 1
        FROM iot_timeseries
        WHERE device_id = p_device_id
        LIMIT 1
    );
END;
$$;


--
-- Name: FUNCTION is_device_used(p_device_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.is_device_used(p_device_id uuid) IS '检查设备是否使用过：用于判断设备是否可以删除。通过检查 iot_timeseries 表中是否有该设备的数据来判断。如果有数据，说明设备一定已安装、已绑定位置（unit/room/bed）、且曾启用监护，因此不能删除。返回 TRUE 表示设备已使用过不能删除，FALSE 表示设备未使用过可以删除';


--
-- Name: unallocate_device_from_tenant(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.unallocate_device_from_tenant(p_device_store_id uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_current_tenant_id UUID;
BEGIN
    -- 检查设备是否存在
    SELECT tenant_id INTO v_current_tenant_id
    FROM device_store
    WHERE device_store_id = p_device_store_id;
    
    IF v_current_tenant_id IS NULL THEN
        RAISE EXCEPTION 'Device not found: %', p_device_store_id;
    END IF;
    
    -- 检查设备是否已分配
    IF v_current_tenant_id = '00000000-0000-0000-0000-000000000000' THEN
        RAISE EXCEPTION 'Device is not allocated to any tenant';
    END IF;
    
    -- Reset to unallocated state
    UPDATE device_store
    SET tenant_id = '00000000-0000-0000-0000-000000000000',
        allocate_time = NULL,
        allow_access = FALSE
    WHERE device_store_id = p_device_store_id;
    
    RETURN TRUE;
END;
$$;


--
-- Name: FUNCTION unallocate_device_from_tenant(p_device_store_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.unallocate_device_from_tenant(p_device_store_id uuid) IS '取消设备分配（系统管理员操作）：将设备标记为未分配状态（tenant_id 重置为默认值，allocate_time 和 allow_access 重置）。仅限系统管理员使用';


--
-- Name: update_alarm_events_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_alarm_events_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: validate_bed_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_bed_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.room_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM rooms r
            WHERE r.room_id = NEW.room_id
              AND r.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Bed room_id % does not belong to tenant %', NEW.room_id, NEW.tenant_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_bed_tenant(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_bed_tenant() IS '验证床位关联的 room 和 resident 属于同一个租户';


--
-- Name: validate_card_bed_unit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_card_bed_unit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_bed_unit_id UUID;
BEGIN
    IF NEW.bed_id IS NOT NULL THEN
        -- 获取 bed 的 unit_id（通过 bed -> room -> unit）
        SELECT u.unit_id INTO v_bed_unit_id
        FROM beds b
        JOIN rooms r ON b.room_id = r.room_id
        JOIN units u ON r.unit_id = u.unit_id
        WHERE b.bed_id = NEW.bed_id;
        
        -- 如果 card 的 unit_id 不为 NULL，验证一致性
        IF NEW.unit_id IS NOT NULL AND v_bed_unit_id != NEW.unit_id THEN
            RAISE EXCEPTION 'Card bed_id % belongs to unit %, but card unit_id is %', 
                NEW.bed_id, v_bed_unit_id, NEW.unit_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_card_bed_unit(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_card_bed_unit() IS '验证卡片 bed 和 unit 的一致性';


--
-- Name: validate_card_resident_bed(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_card_resident_bed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.resident_id IS NOT NULL AND NEW.bed_id IS NOT NULL THEN
        -- 验证 resident 的 bed_id 与 card 的 bed_id 一致
        IF NOT EXISTS (
            SELECT 1
            FROM residents r
            WHERE r.resident_id = NEW.resident_id
              AND r.bed_id = NEW.bed_id
        ) THEN
            RAISE EXCEPTION 'Card resident_id % does not belong to bed_id %', NEW.resident_id, NEW.bed_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_card_resident_bed(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_card_resident_bed() IS '验证卡片 resident 和 bed 的一致性';


--
-- Name: validate_card_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_card_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.bed_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM beds b
            WHERE b.bed_id = NEW.bed_id
              AND b.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Card bed_id % does not belong to tenant %', NEW.bed_id, NEW.tenant_id;
        END IF;
    END IF;
    
    IF NEW.unit_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM units u
            WHERE u.unit_id = NEW.unit_id
              AND u.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Card unit_id % does not belong to tenant %', NEW.unit_id, NEW.tenant_id;
        END IF;
    END IF;
    
    IF NEW.resident_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM residents r
            WHERE r.resident_id = NEW.resident_id
              AND r.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Card resident_id % does not belong to tenant %', NEW.resident_id, NEW.tenant_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_card_tenant(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_card_tenant() IS '验证卡片关联的 bed/unit/resident 属于同一个租户';


--
-- Name: validate_device_bed_room(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_device_bed_room() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_bed_room_id UUID;
BEGIN
    -- 如果设备绑定到 bed，验证 bed 的 room
    IF NEW.bound_bed_id IS NOT NULL THEN
        SELECT room_id INTO v_bed_room_id
        FROM beds
        WHERE bed_id = NEW.bound_bed_id;
        
        -- 如果设备也绑定了 room，验证一致性
        IF NEW.bound_room_id IS NOT NULL AND v_bed_room_id != NEW.bound_room_id THEN
            RAISE EXCEPTION 'Device bound_bed_id % belongs to room %, but bound_room_id is %', 
                NEW.bound_bed_id, v_bed_room_id, NEW.bound_room_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_device_bed_room(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_device_bed_room() IS '验证设备绑定的 bed 和 room 的一致性';


--
-- Name: validate_device_bed_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_device_bed_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.bound_bed_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM beds b
            WHERE b.bed_id = NEW.bound_bed_id
              AND b.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Device bound_bed_id % does not belong to tenant %', NEW.bound_bed_id, NEW.tenant_id;
        END IF;
    END IF;
    
    IF NEW.bound_room_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM rooms r
            WHERE r.room_id = NEW.bound_room_id
              AND r.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Device bound_room_id % does not belong to tenant %', NEW.bound_room_id, NEW.tenant_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_device_bed_tenant(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_device_bed_tenant() IS '验证设备绑定的 bed 和 room 属于同一个租户';


--
-- Name: validate_device_identifier(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_device_identifier() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF (NEW.serial_number IS NULL OR NEW.serial_number = '') 
       AND (NEW.uid IS NULL OR NEW.uid = '') THEN
        RAISE EXCEPTION 'Device must have at least one identifier: serial_number or uid';
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_device_identifier(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_device_identifier() IS '验证设备至少有一个标识符（serial_number 或 uid）';


--
-- Name: validate_device_store_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_device_store_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.device_store_id IS NOT NULL THEN
        -- 如果 device_store 已分配给租户，验证租户一致性
        IF EXISTS (
            SELECT 1
            FROM device_store ds
            WHERE ds.device_store_id = NEW.device_store_id
              AND ds.tenant_id IS NOT NULL
              AND ds.tenant_id != '00000000-0000-0000-0000-000000000000'  -- 排除默认值
              AND ds.tenant_id != NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Device device_store_id % is assigned to a different tenant', NEW.device_store_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_device_store_tenant(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_device_store_tenant() IS '验证设备关联的 device_store 租户一致性（排除默认值）';


--
-- Name: validate_iot_timeseries_location_device(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_iot_timeseries_location_device() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_device_unit_id UUID;
    v_device_room_id UUID;
    v_device_bed_id UUID;
BEGIN
    -- 获取 device 的位置信息
    SELECT d.bound_room_id, d.bound_bed_id INTO v_device_room_id, v_device_bed_id
    FROM devices d
    WHERE d.device_id = NEW.device_id;
    
    -- 如果 device 绑定到 bed，获取 bed 的 room 和 unit
    IF v_device_bed_id IS NOT NULL THEN
        SELECT r.room_id, r.unit_id INTO v_device_room_id, v_device_unit_id
        FROM beds b
        JOIN rooms r ON b.room_id = r.room_id
        WHERE b.bed_id = v_device_bed_id;
    ELSIF v_device_room_id IS NOT NULL THEN
        -- 如果 device 绑定到 room，获取 room 的 unit
        SELECT r.unit_id INTO v_device_unit_id
        FROM rooms r
        WHERE r.room_id = v_device_room_id;
    END IF;
    
    -- 验证 unit_id 一致性（如果两者都不为空）
    IF NEW.unit_id IS NOT NULL AND v_device_unit_id IS NOT NULL THEN
        IF NEW.unit_id != v_device_unit_id THEN
            RAISE EXCEPTION 'iot_timeseries unit_id % does not match device % location (unit_id: %)', 
                NEW.unit_id, NEW.device_id, v_device_unit_id;
        END IF;
    END IF;
    
    -- 验证 room_id 一致性（如果两者都不为空）
    IF NEW.room_id IS NOT NULL AND v_device_room_id IS NOT NULL THEN
        IF NEW.room_id != v_device_room_id THEN
            RAISE EXCEPTION 'iot_timeseries room_id % does not match device % location (room_id: %)', 
                NEW.room_id, NEW.device_id, v_device_room_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_iot_timeseries_location_device(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_iot_timeseries_location_device() IS '验证 iot_timeseries 冗余字段 unit_id 和 room_id 与 device_id 的位置一致性';


--
-- Name: validate_iot_timeseries_location_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_iot_timeseries_location_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.unit_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM units u
            WHERE u.unit_id = NEW.unit_id
              AND u.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'iot_timeseries unit_id % does not belong to tenant %', NEW.unit_id, NEW.tenant_id;
        END IF;
    END IF;
    
    IF NEW.room_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM rooms r
            WHERE r.room_id = NEW.room_id
              AND r.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'iot_timeseries room_id % does not belong to tenant %', NEW.room_id, NEW.tenant_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_iot_timeseries_location_tenant(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_iot_timeseries_location_tenant() IS '验证 iot_timeseries 冗余字段 unit_id 和 room_id 属于同一个租户';


--
-- Name: validate_resident_bed_room(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_resident_bed_room() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.bed_id IS NOT NULL AND NEW.room_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM beds b
            WHERE b.bed_id = NEW.bed_id
              AND b.room_id = NEW.room_id
        ) THEN
            RAISE EXCEPTION 'Resident bed_id % does not belong to room_id %', NEW.bed_id, NEW.room_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_resident_bed_room(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_resident_bed_room() IS '验证住户的 bed 属于指定的 room（如果两者都不为空）';


--
-- Name: validate_resident_caregiver_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_resident_caregiver_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_elem JSONB;
    v_user_id_text TEXT;
    v_uuid_re TEXT := '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
BEGIN
    -- resident_caregivers.resident_id 必须属于 NEW.tenant_id
    IF NOT EXISTS (
        SELECT 1
        FROM residents r
        WHERE r.resident_id = NEW.resident_id
          AND r.tenant_id = NEW.tenant_id
    ) THEN
        RAISE EXCEPTION 'resident_caregivers resident_id % does not belong to tenant %', NEW.resident_id, NEW.tenant_id;
    END IF;

    -- group_list must be a JSON array (if provided)
    IF NEW.group_list IS NOT NULL AND jsonb_typeof(NEW.group_list) <> 'array' THEN
        RAISE EXCEPTION 'resident_caregivers.group_list must be a JSON array';
    END IF;

    -- user_list: validate each referenced user_id belongs to the same tenant
    IF NEW.user_list IS NOT NULL THEN
        IF jsonb_typeof(NEW.user_list) <> 'array' THEN
            RAISE EXCEPTION 'resident_caregivers.user_list must be a JSON array';
        END IF;

        FOR v_elem IN
            SELECT value FROM jsonb_array_elements(NEW.user_list) AS t(value)
        LOOP
            v_user_id_text := NULL;

            IF jsonb_typeof(v_elem) = 'string' THEN
                v_user_id_text := trim(both '"' from v_elem::text);
            ELSIF jsonb_typeof(v_elem) = 'object' AND (v_elem ? 'user_id') THEN
                v_user_id_text := v_elem->>'user_id';
            END IF;

            -- Skip elements we can't interpret as user references (structure is application-defined)
            IF v_user_id_text IS NULL OR v_user_id_text = '' THEN
                CONTINUE;
            END IF;

            IF v_user_id_text !~* v_uuid_re THEN
                RAISE EXCEPTION 'Invalid user_id in resident_caregivers.user_list: %', v_user_id_text;
            END IF;

            IF NOT EXISTS (
                SELECT 1
                FROM users u
                WHERE u.user_id = v_user_id_text::UUID
                  AND u.tenant_id = NEW.tenant_id
            ) THEN
                RAISE EXCEPTION 'resident_caregivers.user_list user_id % does not belong to tenant %', v_user_id_text, NEW.tenant_id;
            END IF;
        END LOOP;
    END IF;

    RETURN NEW;
END;
$_$;


--
-- Name: FUNCTION validate_resident_caregiver_tenant(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_resident_caregiver_tenant() IS '验证住户护理人员属于同一个租户，并验证 group_list 和 user_list 中的用户属于同一租户';


--
-- Name: validate_resident_location_hierarchy(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_resident_location_hierarchy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- 如果指定了 bed_id，则必须同时指定 room_id 和 unit_id
    IF NEW.bed_id IS NOT NULL THEN
        IF NEW.room_id IS NULL THEN
            RAISE EXCEPTION 'Resident bed_id requires room_id to be specified';
        END IF;
        IF NEW.unit_id IS NULL THEN
            RAISE EXCEPTION 'Resident bed_id requires unit_id to be specified';
        END IF;
    END IF;
    
    -- 如果指定了 room_id，则必须同时指定 unit_id
    IF NEW.room_id IS NOT NULL AND NEW.unit_id IS NULL THEN
        RAISE EXCEPTION 'Resident room_id requires unit_id to be specified';
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_resident_location_hierarchy(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_resident_location_hierarchy() IS '验证住户位置绑定的层级关系：如果指定 bed_id，必须同时指定 room_id 和 unit_id；如果指定 room_id，必须同时指定 unit_id';


--
-- Name: validate_resident_location_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_resident_location_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.unit_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM units u
            WHERE u.unit_id = NEW.unit_id
              AND u.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Resident unit_id % does not belong to tenant %', NEW.unit_id, NEW.tenant_id;
        END IF;
    END IF;
    
    IF NEW.room_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM rooms r
            WHERE r.room_id = NEW.room_id
              AND r.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Resident room_id % does not belong to tenant %', NEW.room_id, NEW.tenant_id;
        END IF;
    END IF;
    
    IF NEW.bed_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM beds b
            WHERE b.bed_id = NEW.bed_id
              AND b.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Resident bed_id % does not belong to tenant %', NEW.bed_id, NEW.tenant_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_resident_location_tenant(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_resident_location_tenant() IS '验证住户关联的 unit/room/bed 属于同一个租户';


--
-- Name: validate_resident_room_unit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_resident_room_unit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.room_id IS NOT NULL AND NEW.unit_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM rooms r
            WHERE r.room_id = NEW.room_id
              AND r.unit_id = NEW.unit_id
        ) THEN
            RAISE EXCEPTION 'Resident room_id % does not belong to unit_id %', NEW.room_id, NEW.unit_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_resident_room_unit(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_resident_room_unit() IS '验证住户的 room 属于指定的 unit（如果两者都不为空）';


--
-- Name: validate_room_tenant(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_room_tenant() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.unit_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM units u
            WHERE u.unit_id = NEW.unit_id
              AND u.tenant_id = NEW.tenant_id
        ) THEN
            RAISE EXCEPTION 'Room unit_id % does not belong to tenant %', NEW.unit_id, NEW.tenant_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION validate_room_tenant(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.validate_room_tenant() IS '验证房间关联的 unit 属于同一个租户';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alarm_cloud; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alarm_cloud (
    tenant_id uuid NOT NULL,
    offlinealarm character varying(20) DEFAULT 'ERROR'::character varying,
    lowbattery character varying(20) DEFAULT 'WARNING'::character varying,
    devicefailure character varying(20) DEFAULT 'ERROR'::character varying,
    device_alarms jsonb DEFAULT '{}'::jsonb NOT NULL,
    conditions jsonb,
    notification_rules jsonb,
    metadata jsonb
);


--
-- Name: TABLE alarm_cloud; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.alarm_cloud IS '云端告警策略表：每个租户一条记录，包含所有设备类型的报警策略配置。System tenant 作为默认模板，用于新租户初始化';


--
-- Name: COLUMN alarm_cloud.tenant_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_cloud.tenant_id IS '租户ID（主键）：SystemTenantID 表示系统默认模板；具体租户ID 表示租户特定配置。一个租户只有一条记录';


--
-- Name: COLUMN alarm_cloud.offlinealarm; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_cloud.offlinealarm IS '设备离线报警级别：通用报警，所有设备类型都支持，超越设备型号。NULL=使用全局默认值';


--
-- Name: COLUMN alarm_cloud.lowbattery; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_cloud.lowbattery IS '低电量报警级别：通用报警，所有设备类型都支持，超越设备型号。NULL=使用全局默认值';


--
-- Name: COLUMN alarm_cloud.devicefailure; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_cloud.devicefailure IS '设备故障报警级别：通用报警，所有设备类型都支持，超越设备型号。NULL=使用全局默认值';


--
-- Name: COLUMN alarm_cloud.device_alarms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_cloud.device_alarms IS '设备特定报警配置（JSONB）：包含所有设备类型的报警配置。第一层 key 为设备类型（如 "Radar", "SleepPad"），第二层 key 为报警类型，value 为 DangerLevel。如果某个设备类型的配置不在 device_alarms 中，表示使用系统默认配置';


--
-- Name: COLUMN alarm_cloud.conditions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_cloud.conditions IS '条件/阈值配置（JSONB）：包含阈值范围、持续时长等，为空则使用系统默认（vue_radar 标准）';


--
-- Name: COLUMN alarm_cloud.notification_rules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_cloud.notification_rules IS '通知规则（JSONB）：完整的发送模式配置，包含通知通道、立即发送、重复间隔、升级规则、抑制规则、静默规则等。默认值为 NULL，表示使用用户账户中的个人配置（users 表或 resident_contacts 表中的配置）';


--
-- Name: alarm_device; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alarm_device (
    device_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    monitor_config jsonb DEFAULT '{"alarms": {}}'::jsonb NOT NULL,
    vendor_config jsonb,
    metadata jsonb
);


--
-- Name: TABLE alarm_device; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.alarm_device IS 'IoT 设备实时报警配置表：为每个 IoT 设备存储其完整的监控配置。初次配置时使用 alarm_cloud 的默认值，前端调整后保存完整配置（可能有增有减，与具体型号无关）';


--
-- Name: COLUMN alarm_device.device_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_device.device_id IS '设备ID：主键，每个设备只有一条配置记录';


--
-- Name: COLUMN alarm_device.monitor_config; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_device.monitor_config IS '设备的完整监控配置（JSONB）：包含睡眠时间、各报警项及其级别、阈值等。由前端完全控制，DB 只是保存。初次配置时使用 alarm_cloud 的默认值';


--
-- Name: COLUMN alarm_device.vendor_config; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_device.vendor_config IS '厂家参考配置（JSONB）：厂家给的参考值，方便前端参考。这是只读参考值，不会被修改，前端可以根据此了解设备支持的配置项和典型值';


--
-- Name: alarm_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alarm_events (
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    device_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    category character varying(50),
    alarm_level character varying(20) NOT NULL,
    alarm_status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    triggered_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    hand_time timestamp with time zone,
    iot_timeseries_id bigint,
    trigger_data jsonb,
    handler uuid,
    operation character varying(30),
    notes text,
    notified_users jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alarm_events_alarm_level_check CHECK (((alarm_level)::text = ANY ((ARRAY['0'::character varying, '1'::character varying, '2'::character varying, '3'::character varying, '4'::character varying, '5'::character varying, '6'::character varying, '7'::character varying, 'EMERG'::character varying, 'ALERT'::character varying, 'CRIT'::character varying, 'ERR'::character varying, 'WARNING'::character varying, 'NOTICE'::character varying, 'INFO'::character varying, 'DEBUG'::character varying])::text[]))),
    CONSTRAINT alarm_events_alarm_status_check CHECK (((alarm_status)::text = ANY ((ARRAY['active'::character varying, 'acknowledged'::character varying])::text[]))),
    CONSTRAINT alarm_events_category_check CHECK (((category)::text = ANY ((ARRAY['safety'::character varying, 'clinical'::character varying, 'behavioral'::character varying, 'device'::character varying])::text[]))),
    CONSTRAINT alarm_events_operation_check CHECK (((operation IS NULL) OR ((operation)::text = ANY ((ARRAY['verified_and_processed'::character varying, 'false_alarm'::character varying, 'test'::character varying, 'auto_relieved'::character varying])::text[]))))
);


--
-- Name: TABLE alarm_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.alarm_events IS '报警事件表：记录所有实际发生的报警事件，包括触发数据、状态、处理人等信息';


--
-- Name: COLUMN alarm_events.event_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.event_id IS '事件ID：主键';


--
-- Name: COLUMN alarm_events.tenant_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.tenant_id IS '租户ID';


--
-- Name: COLUMN alarm_events.device_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.device_id IS '设备ID：触发报警的设备';


--
-- Name: COLUMN alarm_events.event_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.event_type IS '事件类型：包括报警事件（如 Fall, Radar_AbnormalHeartRate, SleepPad_LeftBed 等，对应 alarm_cloud 表中的字段名）和设备状态变化事件（如 DeviceOnline 设备上线、DeviceRecovered 设备恢复、AlarmAutoCancelled 报警自动取消等 INFO(6) 级别事件）';


--
-- Name: COLUMN alarm_events.category; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.category IS 'FHIR Category（与 iot_timeseries 表保持一致）：统一使用 FHIR Flag Category 体系。safety（安全告警，如跌倒、疑似跌倒）、clinical（生命体征异常，如心动过速、心动过缓、呼吸暂停）、behavioral（行为健康告警，如超2H未翻身、2H无体动）、device（设备技术告警，如设备故障、传感器断线）。用于快速分类查询和统计';


--
-- Name: COLUMN alarm_events.alarm_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.alarm_level IS '报警级别：对应 TDP DangerLevel 枚举值（完全对齐 Syslog 标准 0-7：0=EMERG, 1=ALERT, 2=CRIT, 3=ERR, 4=WARNING, 5=NOTICE, 6=INFO, 7=DEBUG）。推荐使用完整名称（''ALERT''/''WARNING''等），也支持数字格式（''1''/''4''等）。最终级别 = max(云端级别, IoT级别)。对于护理机构，主要使用 ALERT(1)、CRIT(2)、ERR(3)、WARNING(4)、INFO(6)';


--
-- Name: COLUMN alarm_events.alarm_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.alarm_status IS '报警状态：active（已触发，等待处理）、acknowledged（已确认，正在处理）。注意：INFO(6) 和 DEBUG(7) 级别的事件（如设备上线、设备恢复等）通过 alarm_level 判断，无需单独状态';


--
-- Name: COLUMN alarm_events.triggered_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.triggered_at IS '触发时间：报警触发的时间戳';


--
-- Name: COLUMN alarm_events.hand_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.hand_time IS '处理时间：用户点击确认/处理报警的时间戳';


--
-- Name: COLUMN alarm_events.iot_timeseries_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.iot_timeseries_id IS '关联的 iot_timeseries 记录ID：用于追溯原始数据';


--
-- Name: COLUMN alarm_events.trigger_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.trigger_data IS '触发数据快照（JSONB）：包含触发时的关键数据，如心率值、呼吸率值、姿态、事件类型、置信度、持续时长、阈值等';


--
-- Name: COLUMN alarm_events.handler; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.handler IS '处理人ID：确认或处理报警的用户（test 时可选表示测试者，INFO(6) 级别事件时为 NULL 表示系统自动记录，auto_relieved 时为 NULL 表示设备自动恢复，其他情况下必填表示有人知晓报警事件）';


--
-- Name: COLUMN alarm_events.operation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.operation IS '操作结果（记录"有人知晓报警事件了"的处理操作，elder care 要求所有报警必须人工处理）：verified_and_processed（收到并处理，人工确认并处理了报警事件）、false_alarm（误报，False Alarm，人工标记为误报）、test（测试，测试报警，非真实事件）、auto_relieved（自动解除，仅适用于设备相关报警，当设备恢复时自动解除，如 OfflineAlarm → DeviceOnline）。所有非设备的事件（如床上坐起、离床、生命体征异常、跌倒等）不支持自动解除，如果设置为报警则必须人工处理。对于 INFO(6) 级别的事件（如设备上线、设备恢复等），operation 自动填 NULL（系统自动记录，无需人工操作）。对于需要人工处理的报警事件，NULL 表示尚未处理完成';


--
-- Name: COLUMN alarm_events.notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.notes IS '备注：处理说明、处理结果等';


--
-- Name: COLUMN alarm_events.notified_users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.notified_users IS '通知接收者列表（JSONB）：记录发送了通知的用户，包含用户ID、用户名、通知通道、发送时间等';


--
-- Name: COLUMN alarm_events.metadata; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.metadata IS '元数据（JSONB）：扩展信息，如 related_alarm_id（关联的报警ID，用于事件链追踪）、trigger_source（触发来源：''device'' 表示设备本地触发，''cloud'' 表示云端计算触发）、recovery_reason（自动恢复原因）、auto_cancel_reason（自动取消原因）等';


--
-- Name: COLUMN alarm_events.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.created_at IS '创建时间';


--
-- Name: COLUMN alarm_events.updated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alarm_events.updated_at IS '更新时间（自动更新）';


--
-- Name: beds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.beds (
    bed_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    room_id uuid NOT NULL,
    bed_name character varying(50) NOT NULL,
    mattress_material character varying(50),
    mattress_thickness character varying(20)
);


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    branch_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    branch_name character varying(255) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE branches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.branches IS '院区表：独立的实体，可以独立创建、编辑、删除，不依赖 buildings/units/users 的存在。用于统一管理院区信息，避免 branch_name 在多个表中重复';


--
-- Name: COLUMN branches.branch_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.branches.branch_id IS '院区 ID（主键）';


--
-- Name: COLUMN branches.tenant_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.branches.tenant_id IS '租户 ID（外键）';


--
-- Name: COLUMN branches.branch_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.branches.branch_name IS '院区名称（必填，不能为 NULL，可以为 "-" 表示默认值，同一租户内唯一）';


--
-- Name: COLUMN branches.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.branches.description IS '院区描述（可选）';


--
-- Name: buildings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.buildings (
    building_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    building_name character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE buildings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.buildings IS '楼栋表：独立的实体，可以独立创建、编辑、删除，不依赖 units 的存在';


--
-- Name: COLUMN buildings.building_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.buildings.building_id IS '楼栋 ID（主键）';


--
-- Name: COLUMN buildings.tenant_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.buildings.tenant_id IS '租户 ID（外键）';


--
-- Name: COLUMN buildings.branch_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.buildings.branch_id IS '院区 ID（外键，引用 branches.branch_id，可以为 NULL，表示没有特定院区）';


--
-- Name: COLUMN buildings.building_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.buildings.building_name IS '楼栋名称（必填，不能为 NULL，可以为 "-" 表示默认值）';


--
-- Name: cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cards (
    card_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    card_type character varying(20) NOT NULL,
    bed_id uuid,
    unit_id uuid,
    card_name character varying(255) NOT NULL,
    card_address character varying(255) NOT NULL,
    resident_id uuid,
    devices jsonb DEFAULT '[]'::jsonb NOT NULL,
    residents jsonb DEFAULT '[]'::jsonb NOT NULL,
    unhandled_alarm_0 integer DEFAULT 0 NOT NULL,
    unhandled_alarm_1 integer DEFAULT 0 NOT NULL,
    unhandled_alarm_2 integer DEFAULT 0 NOT NULL,
    unhandled_alarm_3 integer DEFAULT 0 NOT NULL,
    unhandled_alarm_4 integer DEFAULT 0 NOT NULL,
    icon_alarm_level integer DEFAULT 3 NOT NULL,
    pop_alarm_emerge integer DEFAULT 0 NOT NULL,
    CONSTRAINT cards_icon_alarm_level_check CHECK (((icon_alarm_level >= 0) AND (icon_alarm_level <= 4))),
    CONSTRAINT cards_pop_alarm_emerge_check CHECK (((pop_alarm_emerge >= 0) AND (pop_alarm_emerge <= 4))),
    CONSTRAINT chk_card_type_binding CHECK (((((card_type)::text = 'ActiveBed'::text) AND (bed_id IS NOT NULL)) OR (((card_type)::text = 'Location'::text) AND (unit_id IS NOT NULL) AND (bed_id IS NULL))))
);


--
-- Name: config_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_versions (
    version_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    config_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    current_entity_id uuid,
    config_data jsonb NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone
);


--
-- Name: device_store; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_store (
    device_store_id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_type character varying(50) NOT NULL,
    device_model character varying(50),
    serial_number character varying(100),
    uid character varying(50),
    imei character varying(50),
    comm_mode character varying(20),
    mcu_model character varying(50),
    firmware_version character varying(50),
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    import_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    allocate_time timestamp with time zone,
    ota_target_firmware_version character varying(50),
    ota_target_mcu_model character varying(50),
    allow_access boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE device_store; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.device_store IS '设备库存表：系统管理员管理设备库存、分配、出库。租户不直接操作此表，只管理 devices 表（业务设备），控制 business_access。避免频繁的加入/删除操作，提高业务效率';


--
-- Name: COLUMN device_store.device_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.device_type IS '设备类型：非空，如 Radar / SleepPad / VibrationSensor / Gateway 等';


--
-- Name: COLUMN device_store.device_model; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.device_model IS '设备型号：如 WF-RADAR-60G-V2';


--
-- Name: COLUMN device_store.serial_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.serial_number IS '厂家出厂序列号：可空，但 serial_number 与 uid 至少填一个（由应用层校验）';


--
-- Name: COLUMN device_store.uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.uid IS '厂家或平台提供的唯一 UID：可空，但 serial_number 与 uid 至少填一个（由应用层校验）';


--
-- Name: COLUMN device_store.imei; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.imei IS '4G 设备 IMEI：可空，仅 4G 设备需要';


--
-- Name: COLUMN device_store.comm_mode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.comm_mode IS '通讯方式：设备固有属性，如 WiFi / LTE / Zigbee 等';


--
-- Name: COLUMN device_store.mcu_model; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.mcu_model IS 'MCU/主控型号：设备固有属性，可选，如 STM32F4、ESP32 等';


--
-- Name: COLUMN device_store.firmware_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.firmware_version IS '设备当前运行的固件版本：权威数据源，设备上报的实际版本。用于全局 OTA 管理，SystemAdmin 可以统一查看所有设备的当前版本，决定哪些设备可以升级。设备线下手工升级后，租户检测到变化，提交更新到此字段';


--
-- Name: COLUMN device_store.tenant_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.tenant_id IS '租户 ID：默认值为 00000000-0000-0000-0000-000000000000 表示未分配给租户。当分配给租户时，更新为实际租户 ID';


--
-- Name: COLUMN device_store.import_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.import_date IS '入库时间：设备录入系统的时间（系统管理员操作）';


--
-- Name: COLUMN device_store.allocate_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.allocate_time IS '系统管理员分配时间：当 tenant_id 不为默认值时，此字段应被设置。不在租户界面展示，仅用于系统管理员操作记录';


--
-- Name: COLUMN device_store.ota_target_firmware_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.ota_target_firmware_version IS 'OTA 目标固件版本：系统管理员设置的升级目标版本，用于 OTA 升级管理。NULL 表示无升级计划。仅 SystemAdmin 可设置，租户不能决定是否升级（符合服务模式：服务提供商统一负责设备可靠性）。与 firmware_version（设备当前运行的版本）对比，判断是否需要升级';


--
-- Name: COLUMN device_store.ota_target_mcu_model; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.ota_target_mcu_model IS 'OTA 目标 MCU 型号：系统管理员设置的升级目标 MCU 型号（可选）。NULL 表示不升级 MCU。仅 SystemAdmin 可设置，用于需要升级 MCU 固件的场景';


--
-- Name: COLUMN device_store.allow_access; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.device_store.allow_access IS '系统是否允许该设备接入业务系统：系统级别权限控制，由系统管理员设置。不在租户界面展示。设备可以接入业务系统的前提条件之一（另一个是 devices.business_access = TRUE）';


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    device_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    device_store_id uuid,
    device_name character varying(100) NOT NULL,
    serial_number character varying(100),
    uid character varying(50),
    bound_room_id uuid,
    bound_bed_id uuid,
    status character varying(20) DEFAULT 'offline'::character varying NOT NULL,
    business_access character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    monitoring_enabled boolean DEFAULT false NOT NULL,
    metadata jsonb,
    CONSTRAINT chk_device_binding_exclusive CHECK ((((bound_room_id IS NULL) AND (bound_bed_id IS NOT NULL)) OR ((bound_room_id IS NOT NULL) AND (bound_bed_id IS NULL)) OR ((bound_room_id IS NULL) AND (bound_bed_id IS NULL)))),
    CONSTRAINT devices_business_access_check CHECK (((business_access)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: COLUMN devices.device_store_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.devices.device_store_id IS '关联 device_store：通过 device_store_id 直接关联设备库存表，获取设备的物理属性（device_type, device_model, imei, comm_mode, mcu_model）和固件版本（firmware_version）。首次上连时，如果 device_store_id 为空，通过 serial_number/uid 匹配 device_store 后设置此字段';


--
-- Name: COLUMN devices.serial_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.devices.serial_number IS '厂家出厂序列号：用于首次上连时匹配 device_store（如果 device_store_id 为空）。可空，但 serial_number 与 uid 至少填一个（由应用层校验）';


--
-- Name: COLUMN devices.uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.devices.uid IS '厂家或平台提供的唯一 UID：用于首次上连时匹配 device_store（如果 device_store_id 为空）。可空，但 serial_number 与 uid 至少填一个（由应用层校验）';


--
-- Name: COLUMN devices.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.devices.status IS '设备状态：实时状态快照。可能的值：online（在线）、offline（离线）、error（错误）、disabled（已禁用/丢失/故障）。disabled 用于软删除，当设备丢失或故障时设置此状态，而不是删除记录。仅当设备未使用过才能物理删除（使用 is_device_used() 函数检查）';


--
-- Name: iot_timeseries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iot_timeseries (
    id bigint NOT NULL,
    tenant_id uuid NOT NULL,
    device_id uuid NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    data_type character varying(20) DEFAULT 'observation'::character varying NOT NULL,
    category character varying(50),
    tracking_id integer,
    radar_pos_x integer,
    radar_pos_y integer,
    radar_pos_z integer,
    posture_snomed_code character varying(50),
    posture_display character varying(100),
    event_type character varying(50),
    event_snomed_code character varying(50),
    event_display character varying(100),
    area_id integer,
    heart_rate_code character varying(50),
    heart_rate_display character varying(100),
    heart_rate integer,
    respiratory_rate_code character varying(50),
    respiratory_rate_display character varying(100),
    respiratory_rate integer,
    sleep_state_snomed_code character varying(50),
    sleep_state_display character varying(100),
    unit_id uuid,
    room_id uuid,
    alarm_event_id uuid,
    confidence integer,
    remaining_time integer,
    raw_original bytea NOT NULL,
    raw_format character varying(50) NOT NULL,
    raw_compression character varying(50),
    metadata jsonb DEFAULT '{}'::jsonb,
    device_type character varying(50),
    device_model character varying(50),
    serial_number character varying(100),
    uid character varying(50),
    CONSTRAINT iot_timeseries_category_check CHECK (((category)::text = ANY ((ARRAY['vital-signs'::character varying, 'activity'::character varying, 'safety'::character varying, 'clinical'::character varying, 'behavioral'::character varying, 'device'::character varying, 'social-history'::character varying])::text[]))),
    CONSTRAINT iot_timeseries_data_type_check CHECK (((data_type)::text = ANY ((ARRAY['observation'::character varying, 'alarm'::character varying])::text[])))
);


--
-- Name: iot_timeseries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.iot_timeseries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: iot_timeseries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.iot_timeseries_id_seq OWNED BY public.iot_timeseries.id;


--
-- Name: resident_caregivers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resident_caregivers (
    caregiver_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    resident_id uuid NOT NULL,
    group_list jsonb,
    user_list jsonb
);


--
-- Name: resident_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resident_contacts (
    tenant_id uuid NOT NULL,
    resident_id uuid NOT NULL,
    slot character varying(1) NOT NULL,
    relationship character varying(50),
    is_enabled boolean DEFAULT false NOT NULL,
    alert_time_window jsonb,
    contact_first_name character varying(100),
    contact_last_name character varying(100),
    contact_phone character varying(25),
    contact_email character varying(255),
    receive_sms boolean DEFAULT false,
    receive_email boolean DEFAULT false,
    contact_phone_hash character varying(64),
    contact_email_hash character varying(64)
);


--
-- Name: COLUMN resident_contacts.slot; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.resident_contacts.slot IS '槽位标识：用于区分同一住户的多个紧急联系人（A/B/C/D/E）';


--
-- Name: COLUMN resident_contacts.is_enabled; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.resident_contacts.is_enabled IS '是否为紧急联系人：只有 is_emergency_contact = TRUE 的联系人才接收告警。告警级别过滤统一由 alarm_cloud 表决定';


--
-- Name: COLUMN resident_contacts.alert_time_window; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.resident_contacts.alert_time_window IS '告警接收时间窗口：紧急联系人愿意接收告警的时间段（JSONB 对象），格式：{"enabled": true, "start_time": "08:00", "end_time": "22:00", "timezone": "America/Los_Angeles"}。为空或 enabled=false 表示全天接收。只有 is_emergency_contact = TRUE 的联系人，此字段才生效';


--
-- Name: COLUMN resident_contacts.contact_phone; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.resident_contacts.contact_phone IS '联系人电话（可选 PHI）：仅用于发送告警通知（SMS），不用于登录';


--
-- Name: COLUMN resident_contacts.contact_email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.resident_contacts.contact_email IS '联系人邮箱（可选 PHI）：仅用于发送告警通知（Email），不用于登录';


--
-- Name: COLUMN resident_contacts.contact_phone_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.resident_contacts.contact_phone_hash IS '联系人电话 hash（用于搜索功能），可为 NULL';


--
-- Name: COLUMN resident_contacts.contact_email_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.resident_contacts.contact_email_hash IS '联系人邮箱 hash（用于搜索功能），可为 NULL';


--
-- Name: resident_phi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resident_phi (
    phi_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    resident_id uuid NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    gender character varying(10),
    date_of_birth date,
    resident_phone character varying(25),
    resident_email character varying(255),
    weight_lb numeric(5,2),
    height_ft numeric(5,2),
    height_in numeric(5,2),
    mobility_level integer,
    tremor_status character varying(20),
    mobility_aid character varying(20),
    adl_assistance character varying(20),
    comm_status character varying(20),
    has_hypertension boolean,
    has_hyperlipaemia boolean,
    has_hyperglycaemia boolean,
    has_stroke_history boolean,
    has_paralysis boolean,
    has_alzheimer boolean,
    medical_history text,
    home_address_street character varying(255),
    home_address_city character varying(100),
    home_address_state character varying(50),
    home_address_postal_code character varying(20),
    plus_code character varying(32)
);


--
-- Name: residents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.residents (
    resident_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    resident_account character varying(100) NOT NULL,
    resident_account_hash bytea NOT NULL,
    password_hash bytea NOT NULL,
    nickname character varying(100) NOT NULL,
    admission_date date NOT NULL,
    discharge_date date,
    service_level character varying(20) DEFAULT NULL::character varying,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    role character varying(50) DEFAULT 'Resident'::character varying NOT NULL,
    metadata jsonb,
    note text,
    phone character varying(50),
    email character varying(255),
    is_access_enabled boolean DEFAULT false NOT NULL,
    branch_id uuid,
    unit_id uuid,
    room_id uuid,
    bed_id uuid,
    phone_hash bytea,
    email_hash bytea,
    CONSTRAINT residents_check CHECK (((discharge_date IS NULL) OR ((status)::text = ANY ((ARRAY['discharged'::character varying, 'transferred'::character varying])::text[])))),
    CONSTRAINT residents_resident_account_check CHECK (((resident_account)::text = lower((resident_account)::text))),
    CONSTRAINT residents_role_check CHECK (((role)::text = 'Resident'::text)),
    CONSTRAINT residents_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'discharged'::character varying, 'transferred'::character varying])::text[])))
);


--
-- Name: COLUMN residents.nickname; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.residents.nickname IS '昵称：用于匿名化展示和查询，不存储真实姓名。真实姓名存储在 resident_phi 表中（加密存储）。DB 保证 (tenant_id, nickname) 唯一性约束';


--
-- Name: COLUMN residents.discharge_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.residents.discharge_date IS '出院日期：用于记录住户出院/转院的具体日期。仅在 status = ''discharged'' 或 ''transferred'' 时应该有值。用于历史记录查询、统计报表、业务逻辑判断（如设备管理）。非 PII 信息，可以放在 residents 表';


--
-- Name: COLUMN residents.role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.residents.role IS '角色标识：固定为 ''Resident''，用于前端路由识别和权限控制。与 users 表的 role 字段保持一致，便于统一处理';


--
-- Name: COLUMN residents.note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.residents.note IS '客户备注：用于记录日常护理注意事项、行为习惯、家属特殊要求等非 PII 信息。可选字段，由租户管理员填写和维护';


--
-- Name: COLUMN residents.phone; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.residents.phone IS '住户电话（可选 PHI）：用于机构联系客户，不用于登录。包含 PII，需要权限控制';


--
-- Name: COLUMN residents.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.residents.email IS '住户邮箱（可选 PHI）：用于机构联系客户，不用于登录。包含 PII，需要权限控制';


--
-- Name: COLUMN residents.branch_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.residents.branch_id IS '院区 ID（外键，引用 branches.branch_id，可以为 NULL，表示没有特定院区）。用于权限过滤（branch_only）：users.branch_id = residents.branch_id。即使 unit_id 为 NULL（新住户尚未分配房间），也能通过 branch_id 进行权限过滤和分组';


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    permission_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    role_code character varying(50) NOT NULL,
    resource_type character varying(100) NOT NULL,
    permission_type character varying(1) NOT NULL,
    permission_scope character varying(10) NOT NULL,
    CONSTRAINT chk_permission_scope CHECK (((permission_scope)::text = ANY ((ARRAY['A'::character varying, 'S'::character varying, 'B'::character varying])::text[]))),
    CONSTRAINT role_permissions_permission_type_check CHECK (((permission_type)::text = ANY ((ARRAY['R'::character varying, 'C'::character varying, 'U'::character varying, 'D'::character varying])::text[])))
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    role_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    role_code character varying(50) NOT NULL,
    description character varying(255) NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true
);


--
-- Name: TABLE roles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.roles IS 'Roles table: System preset roles (tenant_id = System tenant) and tenant custom roles (tenant_id != System tenant; currently not used). All role permissions are defined in role_permissions table';


--
-- Name: COLUMN roles.tenant_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.roles.tenant_id IS 'Tenant ID: System tenant means system preset role (shared by all tenants); other tenant_id means tenant custom role (currently not used)';


--
-- Name: COLUMN roles.role_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.roles.role_code IS 'Role code: Used for reference in programs/DDL. Staff roles are used in users table, Resident is used in residents table, Family is used in resident_contacts table, Individual is used in users table for personal users (B2C)';


--
-- Name: COLUMN roles.is_system; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.roles.is_system IS 'Whether system preset: TRUE means platform built-in role (tenant_id must be System tenant id). System preset roles (is_system = TRUE) rules: 1) Cannot be modified (description, role_code cannot be changed); 2) Cannot be deleted; 3) Can only be enabled/disabled (is_active field); 4) Disable permissions: Resident, Family, and Individual cannot be disabled by anyone (critical system roles, disabling would break business functionality); SystemAdmin can disable other system roles (except Resident, Family, and Individual); Other roles cannot disable system roles. Tenant custom roles (is_system = FALSE) rules: Can be modified, deleted, enabled/disabled';


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rooms (
    room_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    unit_id uuid NOT NULL,
    room_name character varying(100) NOT NULL,
    layout_config jsonb
);


--
-- Name: round_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.round_details (
    detail_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    round_id uuid NOT NULL,
    resident_id uuid NOT NULL,
    bed_id uuid,
    unit_id uuid,
    bed_status character varying(20),
    sleep_state_snomed_code character varying(50),
    sleep_state_display character varying(100),
    heart_rate integer,
    respiratory_rate integer,
    posture_snomed_code character varying(50),
    posture_display character varying(100),
    data_timestamp timestamp with time zone,
    notes text,
    CONSTRAINT round_details_bed_status_check CHECK (((bed_status)::text = ANY ((ARRAY['in_bed'::character varying, 'out_of_bed'::character varying, 'unknown'::character varying])::text[])))
);


--
-- Name: TABLE round_details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.round_details IS '巡房详细记录表：记录巡房中每个住户的详细状态信息（在床状态、睡眠状态、呼吸、心率、姿态等）。每个住户在每个巡房记录中只有一条详细记录。';


--
-- Name: rounds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rounds (
    round_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    round_type character varying(20) DEFAULT 'location'::character varying NOT NULL,
    unit_id uuid,
    executor_id uuid NOT NULL,
    round_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    notes text,
    status character varying(20) DEFAULT 'completed'::character varying NOT NULL,
    CONSTRAINT rounds_round_type_check CHECK (((round_type)::text = ANY ((ARRAY['location'::character varying, 'manual'::character varying, 'scheduled'::character varying])::text[]))),
    CONSTRAINT rounds_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: TABLE rounds; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.rounds IS '巡房记录表：记录自动巡房的执行记录，帮助院方减轻工作压力。一次巡房操作（rounds）可能包含多个住户的详细记录（round_details），采用一对多关系设计。';


--
-- Name: service_levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_levels (
    level_code character varying(20) NOT NULL,
    description text,
    color character varying(20) NOT NULL,
    color_hex character varying(7),
    priority integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE service_levels; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.service_levels IS '护理级别查找表：统一管理住户的护理级别标识（Independent, Assisted, MemoryCare, FallRisk, VitalRisk, Critical），全局查找表，所有租户共享，类似 snomed_mapping';


--
-- Name: COLUMN service_levels.level_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_levels.level_code IS '级别代码：用于 residents.service_level 字段的值（如 Independent, Assisted, MemoryCare, FallRisk, VitalRisk, Critical），系统预定义，不允许修改。前端可根据 level_code 自行格式化显示';


--
-- Name: COLUMN service_levels.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_levels.description IS '详细描述：护理级别的详细说明';


--
-- Name: COLUMN service_levels.color; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_levels.color IS '颜色代码：颜色标识（如 green, blue, yellow, orange, red, purple, gray）';


--
-- Name: COLUMN service_levels.color_hex; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_levels.color_hex IS '十六进制颜色值：用于前端展示的精确颜色值（如 #28a745），前端可根据需要自行转换为 RGB 或 HSL 格式';


--
-- Name: COLUMN service_levels.priority; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_levels.priority IS '优先级：用于排序和筛选，数字越小优先级越高（1=最低风险, 6=最高风险）';


--
-- Name: sleepace_report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sleepace_report (
    report_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    device_id uuid NOT NULL,
    device_code character varying(100) NOT NULL,
    record_count integer NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint NOT NULL,
    date integer NOT NULL,
    stop_mode integer NOT NULL,
    time_step integer NOT NULL,
    timezone integer NOT NULL,
    sleep_state text,
    report text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: TABLE sleepace_report; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sleepace_report IS 'Sleepace 睡眠报告表，存储从厂家服务获取的睡眠报告数据';


--
-- Name: COLUMN sleepace_report.report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.report_id IS '报告 ID（主键）';


--
-- Name: COLUMN sleepace_report.tenant_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.tenant_id IS '租户 ID';


--
-- Name: COLUMN sleepace_report.device_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.device_id IS '设备 ID（关联 devices 表）';


--
-- Name: COLUMN sleepace_report.device_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.device_code IS '设备编码（来自厂家，等价于 devices.serial_number 或 devices.uid）。不同厂家可能使用不同的标识符：Sleepace 使用 device_code，其他厂家可能使用 serial_number 或 uid。在数据库层，这些标识符是等价的，用于匹配 devices 表中的设备。';


--
-- Name: COLUMN sleepace_report.record_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.record_count IS '记录数量';


--
-- Name: COLUMN sleepace_report.start_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.start_time IS '开始时间（Unix 时间戳，秒）';


--
-- Name: COLUMN sleepace_report.end_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.end_time IS '结束时间（Unix 时间戳，秒）';


--
-- Name: COLUMN sleepace_report.date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.date IS '日期（YYYYMMDD 格式，如 20240820）';


--
-- Name: COLUMN sleepace_report.stop_mode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.stop_mode IS '停止模式';


--
-- Name: COLUMN sleepace_report.time_step; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.time_step IS '时间步长（秒）';


--
-- Name: COLUMN sleepace_report.timezone; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.timezone IS '时区偏移（秒）';


--
-- Name: COLUMN sleepace_report.sleep_state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.sleep_state IS '睡眠状态数组（JSON 字符串）';


--
-- Name: COLUMN sleepace_report.report; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sleepace_report.report IS '完整报告数据（JSON 字符串）';


--
-- Name: snomed_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.snomed_mapping (
    mapping_id uuid DEFAULT gen_random_uuid() NOT NULL,
    mapping_type character varying(20) NOT NULL,
    source_value character varying(50) NOT NULL,
    snomed_code character varying(50),
    snomed_display character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    loinc_code character varying(50),
    display_en character varying(100),
    firmware_version character varying(50),
    duration_threshold_minutes integer,
    CONSTRAINT snomed_mapping_category_check CHECK (((category)::text = ANY ((ARRAY['vital-signs'::character varying, 'activity'::character varying, 'safety'::character varying, 'clinical'::character varying, 'behavioral'::character varying, 'device'::character varying, 'social-history'::character varying])::text[]))),
    CONSTRAINT snomed_mapping_mapping_type_check CHECK (((mapping_type)::text = ANY ((ARRAY['posture'::character varying, 'event'::character varying])::text[])))
);


--
-- Name: TABLE snomed_mapping; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.snomed_mapping IS 'SNOMED 映射表：统一管理所有 SNOMED CT 编码映射，包括姿态映射和事件映射。所有租户共享系统默认映射。';


--
-- Name: COLUMN snomed_mapping.mapping_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.snomed_mapping.mapping_type IS '映射类型：posture（姿态映射）或 event（事件映射）';


--
-- Name: COLUMN snomed_mapping.source_value; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.snomed_mapping.source_value IS '源值：posture 时为设备原始姿态值（如 "0", "1", "2"），event 时为标准事件类型标识符（如 "ENTER_ROOM", "LEFT_BED", "FALL"）';


--
-- Name: COLUMN snomed_mapping.snomed_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.snomed_mapping.snomed_code IS 'SNOMED CT 编码（可为 NULL）';


--
-- Name: COLUMN snomed_mapping.snomed_display; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.snomed_mapping.snomed_display IS 'SNOMED 显示名称（通用英文标准名称，如 "Standing position", "Fall"，便于与外部 HIS/EPIC 对接）';


--
-- Name: COLUMN snomed_mapping.category; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.snomed_mapping.category IS 'FHIR Category：vital-signs（生命体征测量），activity（行为观测），safety（安全告警），clinical（生命体征异常），behavioral（行为健康告警），device（设备技术告警），social-history（环境观测）';


--
-- Name: COLUMN snomed_mapping.firmware_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.snomed_mapping.firmware_version IS '需要的固件版本（用于姿态映射，如 "202406"），NULL 表示所有版本通用';


--
-- Name: COLUMN snomed_mapping.duration_threshold_minutes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.snomed_mapping.duration_threshold_minutes IS '持续时间阈值（用于事件映射，分钟），用于长时间事件判断（如超2H未翻身）';


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    tenant_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_type character varying(20) DEFAULT 'organization'::character varying NOT NULL,
    tenant_name character varying(255) NOT NULL,
    domain character varying(255),
    email character varying(255),
    phone character varying(50),
    status character varying(50) DEFAULT 'active'::character varying,
    metadata jsonb,
    CONSTRAINT tenants_tenant_type_check CHECK (((tenant_type)::text = ANY ((ARRAY['individual'::character varying, 'organization'::character varying])::text[])))
);


--
-- Name: units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.units (
    unit_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    unit_name character varying(255) NOT NULL,
    floor character varying(50),
    layout_config jsonb,
    unit_type character varying(20) NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    is_shared_unit boolean DEFAULT false NOT NULL,
    timezone character varying(50) NOT NULL,
    building_id uuid
);


--
-- Name: COLUMN units.building_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.units.building_id IS '楼栋 ID（外键，允许 NULL，支持 home care 等无 building 的场景）';


--
-- Name: user_branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_branches (
    user_branch_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    is_primary boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE user_branches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_branches IS '用户-院区关联表：支持一个用户属于多个院区的多对多关系。用于权限过滤（branch_only）和告警接收范围过滤（alarm_scope = BRANCH）。支持主院区标识（is_primary），用于默认显示和业务逻辑';


--
-- Name: COLUMN user_branches.user_branch_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_branches.user_branch_id IS '关联 ID（主键）';


--
-- Name: COLUMN user_branches.tenant_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_branches.tenant_id IS '租户 ID（外键）';


--
-- Name: COLUMN user_branches.user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_branches.user_id IS '用户 ID（外键，引用 users.user_id）';


--
-- Name: COLUMN user_branches.branch_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_branches.branch_id IS '院区 ID（外键，引用 branches.branch_id）';


--
-- Name: COLUMN user_branches.is_primary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.user_branches.is_primary IS '是否为主院区（用于默认显示和业务逻辑）。一个用户只能有一个主院区（在同一租户内）';


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    user_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_account character varying(100) NOT NULL,
    user_account_hash bytea NOT NULL,
    nickname character varying(255),
    email character varying(255),
    phone character varying(50),
    email_hash bytea,
    phone_hash bytea,
    password_hash bytea,
    pin_hash bytea,
    role character varying(50) NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying,
    alarm_levels character varying[],
    alarm_channels character varying[],
    alarm_scope character varying(20),
    last_login_at timestamp with time zone,
    user_tags jsonb,
    preferences jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT users_user_account_check CHECK (((user_account)::text = lower((user_account)::text)))
);


--
-- Name: COLUMN users.preferences; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.preferences IS '用户偏好设置（JSONB）：存储用户的 UI 偏好和个性化设置。示例结构：{"vitalFocus": {"selectedCardIds": ["card-id-1", "card-id-2"]}}。vitalFocus.selectedCardIds 用于存储用户在 Vital Focus 页面选中的卡片 ID 列表（Focus 功能）。由前端通过 API 更新，后端只负责存储。如果为 NULL 或字段不存在，表示使用默认值（显示所有有权限的卡片）';


--
-- Name: iot_timeseries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iot_timeseries ALTER COLUMN id SET DEFAULT nextval('public.iot_timeseries_id_seq'::regclass);


--
-- Data for Name: alarm_cloud; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alarm_cloud (tenant_id, offlinealarm, lowbattery, devicefailure, device_alarms, conditions, notification_rules, metadata) FROM stdin;
00000000-0000-0000-0000-000000000001	ERROR	WARNING	ERROR	{"Radar": {"Fall": "EMERGENCY", "Stay": "WARNING", "VitalsWeak": "WARNING", "NoActivity24h": "EMERGENCY", "Radar_LeftBed": "WARNING", "SuspectedFall": "WARNING", "AngleException": "WARNING", "Radar_ApneaHypopnea": "EMERGENCY", "Radar_AbnormalHeartRate": "EMERGENCY", "Radar_AbnormalRespiratoryRate": "EMERGENCY"}, "SleepPad": {"SleepPad_InBed": "DISABLE", "SleepPad_SitUp": "WARNING", "SleepPad_LeftBed": "WARNING", "SleepPad_ApneaHypopnea": "EMERGENCY", "SleepPad_AbnormalHeartRate": "EMERGENCY", "SleepPad_AbnormalBodyMovement": "WARNING", "SleepPad_AbnormalRespiratoryRate": "EMERGENCY"}}	{"heart_rate": {"Normal": {"ranges": [{"max": 95, "min": 55}], "duration_sec": 0}, "WARNING": {"ranges": [{"max": 54, "min": 45}, {"max": 115, "min": 96}], "duration_sec": 300}, "EMERGENCY": {"ranges": [{"max": 44, "min": 0}, {"max": null, "min": 116}], "duration_sec": 60}}, "respiratory_rate": {"Normal": {"ranges": [{"max": 23, "min": 10}], "duration_sec": 0}, "WARNING": {"ranges": [{"max": 9, "min": 8}, {"max": 26, "min": 24}], "duration_sec": 300}, "EMERGENCY": {"ranges": [{"max": 7, "min": 0}, {"max": null, "min": 27}], "duration_sec": 60}}}	{"channels": {"ALERT": ["WEB", "APP"], "ERROR": ["WEB", "APP"], "WARNING": ["WEB", "APP"], "CRITICAL": ["WEB", "APP"], "EMERGENCY": ["WEB", "APP"]}, "immediate": true, "repeat_interval_sec": 300}	\N
bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	WARNING	WARNING	WARNING	{"Radar": {"Fall": "EMERGENCY", "Stay": "WARNING", "VitalsWeak": "EMERGENCY", "WarningArea": "WARNING", "NoActivity24h": "WARNING", "PoorReception": "WARNING", "Radar_LeftBed": "WARNING", "SuspectedFall": "WARNING", "AngleException": "WARNING", "Radar_ApneaHypopnea": "DISABLE", "Radar_AbnormalHeartRate": "EMERGENCY", "Radar_AbnormalRespiratoryRate": "EMERGENCY"}, "SleepPad": {"SleepPad_InBed": "DISABLE", "SleepPad_SitUp": "WARNING", "SleepPad_LeftBed": "WARNING", "SleepPad_ApneaHypopnea": "EMERGENCY", "SleepPad_AbnormalHeartRate": "EMERGENCY", "SleepPad_AbnormalBodyMovement": "WARNING", "SleepPad_AbnormalRespiratoryRate": "EMERGENCY"}}	{"heart_rate": {"Normal": {"ranges": [{"max": 95, "min": 55}], "duration_sec": 0}, "WARNING": {"ranges": [{"max": 54, "min": 45}, {"max": 115, "min": 96}], "duration_sec": 300}, "EMERGENCY": {"ranges": [{"max": 44, "min": 0}, {"max": null, "min": 116}], "duration_sec": 60}}, "respiratory_rate": {"Normal": {"ranges": [{"max": 23, "min": 10}], "duration_sec": 0}, "WARNING": {"ranges": [{"max": 9, "min": 8}, {"max": 26, "min": 24}], "duration_sec": 300}, "EMERGENCY": {"ranges": [{"max": 7, "min": 0}, {"max": null, "min": 27}], "duration_sec": 60}}}	\N	\N
\.


--
-- Data for Name: alarm_device; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alarm_device (device_id, tenant_id, monitor_config, vendor_config, metadata) FROM stdin;
f97bcb13-585c-4e3d-b5e3-3e618223a4e7	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	{"alarms": {"Fall": {"enabled": true}, "OnBed": {"level": "DISABLED", "enabled": true, "threshold": {"duration": 300}}, "SitUp": {"level": "WARNING", "enabled": true}, "BodyMove": {"level": "WARNING", "enabled": true, "threshold": {"duration": 10}}, "HeartRate": {"level": "EMERGENCY", "enabled": true, "threshold": {"max": 120, "min": 45, "fast_duration": 600, "slow_duration": 600}}, "BreathRate": {"level": "EMERGENCY", "enabled": true, "threshold": {"max": 24, "min": 10, "fast_duration": 120, "slow_duration": 300}}, "NoTurnOver": {"level": "WARNING", "enabled": true, "threshold": {"duration": 120}}, "NobodyMove": {"level": "WARNING", "enabled": true, "threshold": {"duration": 45}}, "BreathPause": {"level": "EMERGENCY", "enabled": true, "threshold": {"duration": 30}}, "SleepPad_LeftBed": {"level": "WARNING", "enabled": true, "threshold": {"duration": 2700, "end_hour": 7, "end_minute": 30, "start_hour": 21, "start_minute": 30}}}}	\N	\N
0379f811-83dd-4c88-8a45-28572e395d66	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	{"alarms": {"Fall": {"level": "0", "enabled": true, "threshold": {"duration": 30}}, "Stay": {"level": "WARNING", "enabled": true, "threshold": {"duration": 45}}, "VitalsWeak": {"level": "EMERGENCY", "enabled": true, "threshold": {"duration": 5, "sensitivity": 35}}, "NoActivity24h": {"level": "WARNING", "enabled": true}, "Radar_LeftBed": {"level": "WARNING", "enabled": true, "threshold": {"duration": 45, "end_hour": 7, "end_minute": 30, "start_hour": 21, "start_minute": 30}}, "AngleException": {"enabled": true}, "SittingOnGround": {"enabled": true, "threshold": {"duration": 90}}, "Radar_ApneaHypopnea": {"level": "DISABLED", "enabled": true}, "Radar_AbnormalHeartRate": {"level": "EMERGENCY", "enabled": true, "threshold": {"max": 100, "min": 50}}, "Radar_AbnormalRespiratoryRate": {"level": "EMERGENCY", "enabled": true, "threshold": {"max": 26, "min": 8}}}}	\N	\N
\.


--
-- Data for Name: alarm_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alarm_events (event_id, tenant_id, device_id, event_type, category, alarm_level, alarm_status, triggered_at, hand_time, iot_timeseries_id, trigger_data, handler, operation, notes, notified_users, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: beds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.beds (bed_id, tenant_id, room_id, bed_name, mattress_material, mattress_thickness) FROM stdin;
5c81b055-1920-4d30-b17e-7e20037b0c62	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	a8a03532-e213-48b0-87f1-eb00db32b6f5	BedA	\N	\N
e1e52883-8a2f-40b8-b54d-c84821a37fcd	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	a8a03532-e213-48b0-87f1-eb00db32b6f5	BedB	\N	\N
9494b1d3-0d68-4c21-af42-8a9d11135f8c	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	4e7e5965-2af4-4a1f-91a1-b523e42de8e8	BedA	\N	\N
1025417c-e2d3-40ec-b9ea-9563ac646dcd	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	02930aec-32ea-4379-b14e-e9f17fffe599	BedA	\N	\N
27b8ace6-c6af-4d67-89f1-71b43b187d7e	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	02930aec-32ea-4379-b14e-e9f17fffe599	BedB	\N	\N
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branches (branch_id, tenant_id, branch_name, description, created_at, updated_at) FROM stdin;
6b7bd97a-42e4-4086-8232-ecf7ae545eec	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	DV	denver	2025-12-29 08:33:56.619559	2025-12-29 08:33:56.619559
2f614eec-5bbc-492b-9f9b-8e1d22b14d2b	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	SP	sprint	2025-12-29 08:34:06.214664	2025-12-29 08:34:06.214664
\.


--
-- Data for Name: buildings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.buildings (building_id, tenant_id, branch_id, building_name, created_at, updated_at) FROM stdin;
528ebbf0-5657-4f77-a87d-f2523dfcdfd8	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	6b7bd97a-42e4-4086-8232-ecf7ae545eec	A	2025-12-29 08:56:37.595631	2025-12-29 08:56:37.595631
ad49ccc1-2165-4ced-9774-fe4ae4ff6189	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2f614eec-5bbc-492b-9f9b-8e1d22b14d2b	H	2025-12-29 08:56:54.098983	2025-12-29 08:56:54.098983
e090cb4b-6dd3-44ac-9cbc-a5121b2b255a	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	6b7bd97a-42e4-4086-8232-ecf7ae545eec	B	2026-01-08 04:33:45.591781	2026-01-08 04:33:45.591781
\.


--
-- Data for Name: cards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cards (card_id, tenant_id, card_type, bed_id, unit_id, card_name, card_address, resident_id, devices, residents, unhandled_alarm_0, unhandled_alarm_1, unhandled_alarm_2, unhandled_alarm_3, unhandled_alarm_4, icon_alarm_level, pop_alarm_emerge) FROM stdin;
19b16fad-5f4f-49ad-85b2-19fbf1dc4ecc	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	ActiveBed	5c81b055-1920-4d30-b17e-7e20037b0c62	d8b82a88-30c3-4c62-a7c5-c4d88d495619	D• R*	DV-A-E101	b266ec84-c626-41ad-8bdd-3a72b4194fc0	[{"bed_id": "5c81b055-1920-4d30-b17e-7e20037b0c62", "unit_id": "d8b82a88-30c3-4c62-a7c5-c4d88d495619", "bed_name": "BedA", "device_id": "2762da97-520c-4b09-a60d-7c3e6d81b9b2", "room_name": "bedroom", "device_name": "Sleepad-9pv1", "device_type": "sleepad", "device_model": "BM8701-2"}]	[{"nickname": "D• R*", "resident_id": "b266ec84-c626-41ad-8bdd-3a72b4194fc0"}]	0	0	0	0	0	3	0
90ff19ed-2f6b-4dd1-9e6c-bce9390d1679	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	ActiveBed	e1e52883-8a2f-40b8-b54d-c84821a37fcd	d8b82a88-30c3-4c62-a7c5-c4d88d495619	D• R*2	DV-A-E101	9b1af5b5-b3c3-4aaa-b96c-7d6eb500c67f	[{"bed_id": "e1e52883-8a2f-40b8-b54d-c84821a37fcd", "unit_id": "d8b82a88-30c3-4c62-a7c5-c4d88d495619", "bed_name": "BedB", "device_id": "b6ada3b2-48bb-4dfc-ad29-d081d35dbc44", "room_name": "bedroom", "device_name": "Sleepad-a9fb", "device_type": "Sleepad", "device_model": "BM8701-2"}]	[{"nickname": "D• R*2", "resident_id": "9b1af5b5-b3c3-4aaa-b96c-7d6eb500c67f"}]	0	0	0	0	0	3	0
fd8f62a2-2bca-4556-9fb6-a6f48f9110d7	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	Location	\N	d8b82a88-30c3-4c62-a7c5-c4d88d495619	E101	DV-A-E101	\N	[{"room_id": "472b2643-e4e7-40ac-bdae-0413aee8b1cd", "unit_id": "d8b82a88-30c3-4c62-a7c5-c4d88d495619", "device_id": "a48f74fd-579e-4888-b597-8aeaef9b6f60", "room_name": "bathroom", "device_name": "Radar-09E7", "device_type": "Radar", "device_model": "HC2"}]	[{"nickname": "D• R*", "resident_id": "b266ec84-c626-41ad-8bdd-3a72b4194fc0"}, {"nickname": "D• R*2", "resident_id": "9b1af5b5-b3c3-4aaa-b96c-7d6eb500c67f"}]	0	0	0	0	0	3	0
11c7b974-987b-4df2-b408-33b1da94bc40	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	ActiveBed	9494b1d3-0d68-4c21-af42-8a9d11135f8c	833c522b-7f8b-4415-8e2f-71a8f8c4dafc	D• R*p	DV-A-E301	\N	[{"bed_id": "9494b1d3-0d68-4c21-af42-8a9d11135f8c", "unit_id": "833c522b-7f8b-4415-8e2f-71a8f8c4dafc", "bed_name": "BedA", "device_id": "f97bcb13-585c-4e3d-b5e3-3e618223a4e7", "room_name": "bedroom", "device_name": "Sleepad-wn5u", "device_type": "sleepad", "device_model": "BM8701-2"}, {"room_id": "d9166bc1-4387-4de1-955c-81445efec204", "unit_id": "833c522b-7f8b-4415-8e2f-71a8f8c4dafc", "device_id": "0379f811-83dd-4c88-8a45-28572e395d66", "room_name": "bathroom", "device_name": "Radar-1797", "device_type": "Radar", "device_model": "HC2"}, {"room_id": "258cde35-7065-483e-adde-8d7e1343ef3d", "unit_id": "833c522b-7f8b-4415-8e2f-71a8f8c4dafc", "device_id": "811ad945-9f42-4dfe-8190-b9307bfa38f5", "room_name": "bookroom", "device_name": "Radar-333B", "device_type": "Radar", "device_model": "HC2"}]	[{"nickname": "D• R*p", "resident_id": "9013ccb6-5c43-4d21-8b2c-4da688a6a50e"}]	0	0	0	0	0	3	0
\.


--
-- Data for Name: config_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_versions (version_id, tenant_id, config_type, entity_id, current_entity_id, config_data, valid_from, valid_to) FROM stdin;
\.


--
-- Data for Name: device_store; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_store (device_store_id, device_type, device_model, serial_number, uid, imei, comm_mode, mcu_model, firmware_version, tenant_id, import_date, allocate_time, ota_target_firmware_version, ota_target_mcu_model, allow_access) FROM stdin;
5227b489-d371-4a2e-b06b-468a8f04887a	Radar	HC2	25A859B8333B	25A859B8333B	\N	wifi	\N	\N	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2025-12-31 09:43:15.527479+00	2025-12-31 09:43:50.820774+00	\N	\N	t
e4ca7c65-2ee6-4203-b25b-e9f374894e25	Radar	HC2	4D8710F41797	4D8710F41797	\N	wifi	\N	\N	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2025-12-31 09:43:15.527479+00	2025-12-31 09:43:50.820774+00	\N	\N	t
f22a0afa-e41a-4d1b-9c4c-fff22a31fa95	Radar	HC2	9D8A326309E7	9D8A326309E7	\N	wifi	\N	\N	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2025-12-31 09:43:15.527479+00	2025-12-31 09:43:50.820774+00	\N	\N	t
0db691ce-5a27-4e3a-b247-35730ab50b5b	Radar	HC2	9D8A32A1CD2B	9D8A32A1CD2B	\N	wifi	\N	\N	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2025-12-31 09:43:15.527479+00	2025-12-31 09:43:50.820774+00	\N	\N	t
c4f08b92-83a7-43c7-b828-9d3844bfcdf6	Sleepad	BM8701-2	tpbp407pka9fb	BM87224601335	\N	wifi	\N	\N	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
ba204a77-9b51-4ba9-802b-2f1d9f1245f7	sleepad	BM8701-2	1ua3erivl9pv1	BM87224601903	\N	wifi	\N	\N	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
9d344ed4-051f-4cf8-8969-6b4f1afe5901	sleepad	BM8701-2	2cf3xwzy8wn5u	BM87224700967	\N	wifi	\N	\N	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
1b0919f8-3174-4518-b559-a2119727a3ef	sleepad	BM8701-2	8amzqonkfyfyy	BM87224700978	\N	wifi	\N	\N	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
9bbf16c7-d8ff-412d-8e58-8402d6e65d2a	sleepad	BM8701-2	i5udjmqyr0dvc	BM87224700861	\N	wifi	\N	\N	beefa852-9c2f-4641-8212-897d0f57c938	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
32075513-36e5-4f62-88ee-3b957bfef35c	sleepad	BM8701-2	ka9hv61zy0qy7	BM87225200677	\N	wifi	\N	\N	beefa852-9c2f-4641-8212-897d0f57c938	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
41cfa995-83f4-4ed5-a021-1b4e4fa450a2	sleepad	BM8701-2	m5ancbmz6rwx2	BM87224700863	\N	wifi	\N	\N	beefa852-9c2f-4641-8212-897d0f57c938	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
d457436c-3bfa-4dc4-8cf6-114bb218b371	sleepad	BM8701-2	o2vo4y13he1g2	BM87224601897	\N	wifi	\N	\N	beefa852-9c2f-4641-8212-897d0f57c938	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
01bda471-be87-45b1-9afd-ca909cfd01c1	sleepad	BM8701-2	qziygq7zpoedj	BM87224601641	\N	wifi	\N	\N	18842522-420e-467d-abc0-bfe91f320525	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
7616fbe3-5096-4d77-b4e0-e33bc7d6dbff	sleepad	BM8701-2	r0nqo00b34vtf	BM87225200672	\N	wifi	\N	\N	18842522-420e-467d-abc0-bfe91f320525	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
fd422003-92cd-4cd5-9099-f88c482f6bf7	sleepad	BM8701-2	w4lc57jlk4n4d	BM87224700865	\N	wifi	\N	\N	18842522-420e-467d-abc0-bfe91f320525	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
51f20560-db7e-4367-b76d-91c6054441c9	sleepad	BM8701-2	ynrsccv2nxjzb	BM87224700961	\N	wifi	\N	\N	18842522-420e-467d-abc0-bfe91f320525	2025-12-31 09:43:15.527479+00	2026-01-03 02:24:28.347235+00	\N	\N	t
3833f08c-5747-468f-80a9-b69007f67328	Radar	TSL60G442	4D8710D5CABB	4D8710D5CABB	\N	wifi	\N	\N	beefa852-9c2f-4641-8212-897d0f57c938	2025-12-31 09:43:15.527479+00	2025-12-31 09:43:50.820774+00	\N	\N	t
8d183074-33d4-4a4d-bdad-c3c416d2731b	Radar	TSL60G442	55A1B66CD747	55A1B66CD747	\N	wifi	\N	\N	beefa852-9c2f-4641-8212-897d0f57c938	2025-12-31 09:43:15.527479+00	2025-12-31 09:43:50.820774+00	\N	\N	t
5a72d78d-92b5-4e83-ad11-4ebe82f76fa1	Radar	TSL60G442	E598A2ACC543	E598A2ACC543	\N	wifi	\N	\N	beefa852-9c2f-4641-8212-897d0f57c938	2025-12-31 09:43:15.527479+00	2025-12-31 09:43:50.820774+00	\N	\N	t
d4eb9bb7-9e43-48e7-8a47-a36519ae07f2	Radar	TSL60G442	E598A2ACD51B	E598A2ACD51B	\N	wifi	\N	\N	beefa852-9c2f-4641-8212-897d0f57c938	2025-12-31 09:43:15.527479+00	2026-01-03 02:28:58.090341+00	\N	\N	t
2372d1c4-deab-45a2-982d-53472c9413a6	Radar	TSL60G442	E598A2ACD5DB	E598A2ACD5DB	\N	wifi	\N	\N	18842522-420e-467d-abc0-bfe91f320525	2025-12-31 09:43:15.527479+00	2026-01-03 02:28:58.090341+00	\N	\N	t
bb3322c1-0462-45ec-9de5-87e9948b19bf	Radar	TSL60G442	E598A2ACD5F7	E598A2ACD5F7	\N	wifi	\N	\N	18842522-420e-467d-abc0-bfe91f320525	2025-12-31 09:43:15.527479+00	2026-01-03 02:28:58.090341+00	\N	\N	t
791fc634-69de-4987-b7eb-803c17e545a5	Radar	TSL60G442	E598A2ACD523	E598A2ACD523	\N	wifi	\N	\N	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2025-12-31 09:43:15.527479+00	2026-01-03 02:28:58.090341+00	\N	\N	t
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (device_id, tenant_id, device_store_id, device_name, serial_number, uid, bound_room_id, bound_bed_id, status, business_access, monitoring_enabled, metadata) FROM stdin;
0379f811-83dd-4c88-8a45-28572e395d66	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	e4ca7c65-2ee6-4203-b25b-e9f374894e25	Radar-1797	4D8710F41797	4D8710F41797	d9166bc1-4387-4de1-955c-81445efec204	\N	offline	approved	t	\N
811ad945-9f42-4dfe-8190-b9307bfa38f5	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	5227b489-d371-4a2e-b06b-468a8f04887a	Radar-333B	25A859B8333B	25A859B8333B	258cde35-7065-483e-adde-8d7e1343ef3d	\N	offline	approved	t	\N
2762da97-520c-4b09-a60d-7c3e6d81b9b2	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	ba204a77-9b51-4ba9-802b-2f1d9f1245f7	Sleepad-9pv1	1ua3erivl9pv1	BM87224601903	\N	5c81b055-1920-4d30-b17e-7e20037b0c62	offline	approved	t	\N
b6ada3b2-48bb-4dfc-ad29-d081d35dbc44	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	c4f08b92-83a7-43c7-b828-9d3844bfcdf6	Sleepad-a9fb	tpbp407pka9fb	BM87224601335	\N	e1e52883-8a2f-40b8-b54d-c84821a37fcd	offline	approved	t	\N
a48f74fd-579e-4888-b597-8aeaef9b6f60	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	f22a0afa-e41a-4d1b-9c4c-fff22a31fa95	Radar-09E7	9D8A326309E7	9D8A326309E7	472b2643-e4e7-40ac-bdae-0413aee8b1cd	\N	offline	approved	t	\N
f97bcb13-585c-4e3d-b5e3-3e618223a4e7	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	9d344ed4-051f-4cf8-8969-6b4f1afe5901	Sleepad-wn5u	2cf3xwzy8wn5u	BM87224700967	\N	9494b1d3-0d68-4c21-af42-8a9d11135f8c	offline	approved	t	\N
3b941ea7-b474-4a1c-ba83-9e5457ed9583	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	0db691ce-5a27-4e3a-b247-35730ab50b5b	Radar-CD2B	9D8A32A1CD2B	9D8A32A1CD2B	\N	\N	offline	approved	t	\N
5efa4d57-522e-4923-80c8-4e14ecf0c05a	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	1b0919f8-3174-4518-b559-a2119727a3ef	Sleepad-yfyy	8amzqonkfyfyy	BM87224700978	\N	\N	offline	approved	t	\N
00000000-0000-0000-0001-000000000001	00000000-0000-0000-0000-000000000001	\N	Sleepad001	Sleepad001	\N	\N	\N	active	approved	f	\N
00000000-0000-0000-0001-000000000002	00000000-0000-0000-0000-000000000001	\N	Radar001	Radar001	\N	\N	\N	active	approved	f	\N
\.


--
-- Data for Name: iot_timeseries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.iot_timeseries (id, tenant_id, device_id, "timestamp", data_type, category, tracking_id, radar_pos_x, radar_pos_y, radar_pos_z, posture_snomed_code, posture_display, event_type, event_snomed_code, event_display, area_id, heart_rate_code, heart_rate_display, heart_rate, respiratory_rate_code, respiratory_rate_display, respiratory_rate, sleep_state_snomed_code, sleep_state_display, unit_id, room_id, alarm_event_id, confidence, remaining_time, raw_original, raw_format, raw_compression, metadata, device_type, device_model, serial_number, uid) FROM stdin;
\.


--
-- Data for Name: resident_caregivers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resident_caregivers (caregiver_id, tenant_id, resident_id, group_list, user_list) FROM stdin;
25e2b723-67ff-4158-a3c7-1574b5534511	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	9b1af5b5-b3c3-4aaa-b96c-7d6eb500c67f	["Memory"]	["029f6ad1-aaf5-4904-b430-e8e76e727718"]
9d86ec3e-fc18-4fb1-9b7b-16903cebb285	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	9013ccb6-5c43-4d21-8b2c-4da688a6a50e	[]	["571f6e61-d841-4822-9f76-1987abe3666a", "1e5616e3-3739-4835-8d95-afb4a3933ab6"]
0bb2e044-ff03-4d4b-b88b-5c30fe9ea913	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	b266ec84-c626-41ad-8bdd-3a72b4194fc0	[]	["c3b9bde2-4be4-4671-af81-f79694486932", "029f6ad1-aaf5-4904-b430-e8e76e727718"]
\.


--
-- Data for Name: resident_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resident_contacts (tenant_id, resident_id, slot, relationship, is_enabled, alert_time_window, contact_first_name, contact_last_name, contact_phone, contact_email, receive_sms, receive_email, contact_phone_hash, contact_email_hash) FROM stdin;
bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	b266ec84-c626-41ad-8bdd-3a72b4194fc0	A	Child	t	\N	DV	R1A	\N	r1a@demo.com	f	f	\N	b60f36f83ff6404b695168d3c4251aac6082f5c1d1c4fee2a52d07c3771df55b
bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	b266ec84-c626-41ad-8bdd-3a72b4194fc0	B	Child	t	\N	DV	R1B	\N	r1b@demo.com	f	f	\N	f7b9e46030bb72ed79ed93ac0bf92b0667fb656ba302fcd4fa276093fd7e5efc
bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	9b1af5b5-b3c3-4aaa-b96c-7d6eb500c67f	A	Child	t	\N	DV	R2A	\N	r2a@demo.com	f	f	\N	7d161564a3243519ca2187c643a4203d9188143daf382b8d9211e339535e86eb
bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	9b1af5b5-b3c3-4aaa-b96c-7d6eb500c67f	B	Spouse	t	\N	DV	R2B	7201002202	r2b@demo.com	f	f	6bb34b97c0642ca251a3141dd3a76b768034567953a2b69bb694d0f056a02f16	ce0356fe72964a880757d08c5a72ea4352f715f84e41003d64e010d5639b73eb
bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	9013ccb6-5c43-4d21-8b2c-4da688a6a50e	A	Other	t	\N	DV	R3a	\N	r3a@demo.com	f	f	\N	52441fdfd66362a64cac5d25ab7a931751b6592c50a27602a41dc2cc85cc10df
\.


--
-- Data for Name: resident_phi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resident_phi (phi_id, tenant_id, resident_id, first_name, last_name, gender, date_of_birth, resident_phone, resident_email, weight_lb, height_ft, height_in, mobility_level, tremor_status, mobility_aid, adl_assistance, comm_status, has_hypertension, has_hyperlipaemia, has_hyperglycaemia, has_stroke_history, has_paralysis, has_alzheimer, medical_history, home_address_street, home_address_city, home_address_state, home_address_postal_code, plus_code) FROM stdin;
49ad7ba9-5114-4f51-a5cb-784529f5fb90	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	9b1af5b5-b3c3-4aaa-b96c-7d6eb500c67f	DV	R2	Female	1944-12-29	\N	***@***	102.00	5.00	2.00	\N	\N	\N	\N	Normal	f	f	f	f	f	t	test	a	\N	\N	\N	\N
330e3b49-7cea-4b78-92f8-aecebd5dafec	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	9013ccb6-5c43-4d21-8b2c-4da688a6a50e	DV	R3vip	Male	1944-12-23	\N	***@***	103.00	5.00	3.00	5	\N	\N	Independent	Normal	t	t	t	f	f	f	\N	\N	\N	\N	\N	\N
39e1eaac-5536-4333-9032-6844ff9d58d4	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	b266ec84-c626-41ad-8bdd-3a72b4194fc0	DV	R1	Male	1944-12-11	\N	r1@demo.com	100.00	4.00	\N	0	None	\N	\N	\N	t	t	f	f	f	f	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: residents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.residents (resident_id, tenant_id, resident_account, resident_account_hash, password_hash, nickname, admission_date, discharge_date, service_level, status, role, metadata, note, phone, email, is_access_enabled, branch_id, unit_id, room_id, bed_id, phone_hash, email_hash) FROM stdin;
9013ccb6-5c43-4d21-8b2c-4da688a6a50e	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	r3	\\xe49d63b2a8a78f048bafc4b4590029603a5a4165ee8bf98af15d62f24cd83479	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	D• R*p	2025-12-30	\N	Independent	active	Resident	\N	DV R3 private	\N	***@***	t	6b7bd97a-42e4-4086-8232-ecf7ae545eec	833c522b-7f8b-4415-8e2f-71a8f8c4dafc	\N	\N	\N	\\x5b8ac00989d858ab375211bef9b4ef319455ab03a4f9d9df14e89847fbac24ec
b266ec84-c626-41ad-8bdd-3a72b4194fc0	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	r1	\\x82f3e9c695dc6b8d1b11818d5701919e286de8d47f7c3eb3100c485f79e57828	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	D• R*	2025-12-08	\N	Independent	active	Resident	\N	DV R1	\N	r1@demo.com	t	6b7bd97a-42e4-4086-8232-ecf7ae545eec	d8b82a88-30c3-4c62-a7c5-c4d88d495619	a8a03532-e213-48b0-87f1-eb00db32b6f5	5c81b055-1920-4d30-b17e-7e20037b0c62	\N	\\x37abbd452c55a8941a01008f29fcc69427e989a32c1f0ab74c5a3d363c1c5825
9b1af5b5-b3c3-4aaa-b96c-7d6eb500c67f	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	r2	\\xdb77fd01af957221a4989b64b3770a83a3c56068405b9f0e9408feae57fd17e4	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	D• R*2	2025-11-28	\N	Assisted	active	Resident	\N	DV R2	\N	***@***	t	6b7bd97a-42e4-4086-8232-ecf7ae545eec	d8b82a88-30c3-4c62-a7c5-c4d88d495619	a8a03532-e213-48b0-87f1-eb00db32b6f5	e1e52883-8a2f-40b8-b54d-c84821a37fcd	\N	\\x347fde8b5c1db727150d3d0a224d7431f7de87ca6b642277dfbfa45e28fd34c4
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (permission_id, tenant_id, role_code, resource_type, permission_type, permission_scope) FROM stdin;
9d33c4d1-d5f8-4000-bfd9-2936e7bd4ba8	00000000-0000-0000-0000-000000000001	Admin	alarm_cloud	C	A
bccd6285-e659-4a85-ba27-340931e64a22	00000000-0000-0000-0000-000000000001	Admin	alarm_cloud	D	A
db2ed08c-64d9-4e83-b432-0654a980c5fd	00000000-0000-0000-0000-000000000001	Admin	alarm_cloud	R	A
59ef051c-f1af-4960-85a2-b94f838d2dcc	00000000-0000-0000-0000-000000000001	Admin	alarm_cloud	U	A
2ac7d0ff-697a-44a9-9dbb-358e4581358c	00000000-0000-0000-0000-000000000001	Admin	alarm_device	C	A
b1f83c15-18aa-4995-adcf-6db9935b7a46	00000000-0000-0000-0000-000000000001	Admin	alarm_device	D	A
994759b5-7d76-4783-aa83-45e554cd1d3b	00000000-0000-0000-0000-000000000001	Admin	alarm_device	R	A
3e0dbb7b-1243-4302-bd81-eef16f3c8e0d	00000000-0000-0000-0000-000000000001	Admin	alarm_device	U	A
184bb29d-9b25-4e50-9f89-b30a04346c50	00000000-0000-0000-0000-000000000001	Admin	alarm_events	C	A
973421db-6809-4bfa-8b8c-f506c219ee45	00000000-0000-0000-0000-000000000001	Admin	alarm_events	D	A
e7e0ce0a-a6d5-458e-9313-daa74ee832e7	00000000-0000-0000-0000-000000000001	Admin	alarm_events	R	A
c5a785e0-74ac-4b48-bf6b-7f3a3b910afa	00000000-0000-0000-0000-000000000001	Admin	alarm_events	U	A
216b67f9-6eaa-4d0c-b89a-9eee81eec790	00000000-0000-0000-0000-000000000001	Admin	beds	C	A
bdd36b21-17b0-4525-841e-067cefbe1b13	00000000-0000-0000-0000-000000000001	Admin	beds	D	A
a8b9e714-344b-428c-9fa2-13e63a64b9b9	00000000-0000-0000-0000-000000000001	Admin	beds	R	A
30c743b6-77dc-4f5a-9351-af957ecbb6b3	00000000-0000-0000-0000-000000000001	Admin	beds	U	A
1a77379d-cb8f-41d5-a1c1-76c2dc2764cb	00000000-0000-0000-0000-000000000001	Manager	alarm_cloud	C	B
597abaee-c9fb-442f-96cf-1a69f79e22a4	00000000-0000-0000-0000-000000000001	Manager	alarm_cloud	D	B
887fd2b2-9d9f-4d5a-80fa-e9844ec06d45	00000000-0000-0000-0000-000000000001	Admin	cards	C	A
2c8892ee-8417-4a52-bb90-37a30a56eccf	00000000-0000-0000-0000-000000000001	Admin	cards	D	A
fb058c38-a70e-4f24-87dc-7b7380784d75	00000000-0000-0000-0000-000000000001	Admin	cards	R	A
e19b2df0-b138-4868-b549-e06f675b4d38	00000000-0000-0000-0000-000000000001	Admin	cards	U	A
999bf2b3-fce4-4e70-8dd6-54b7cdf6ff26	00000000-0000-0000-0000-000000000001	Admin	config_versions	C	A
be3c33d4-2287-4340-a9e3-3e92cc93e01b	00000000-0000-0000-0000-000000000001	Admin	config_versions	D	A
9d9f1c58-bbf6-4f0c-a186-7a70c2649ba2	00000000-0000-0000-0000-000000000001	Admin	config_versions	R	A
3f750440-01fa-4031-8b4e-881f48c23187	00000000-0000-0000-0000-000000000001	Admin	config_versions	U	A
55735065-1396-426f-ad8c-5207a89d0964	00000000-0000-0000-0000-000000000001	Admin	device_store	R	S
56119859-5476-48e1-ad6c-e0069fd79172	00000000-0000-0000-0000-000000000001	Admin	devices	C	A
ce1946ed-e102-405f-b877-8638ba9f7fae	00000000-0000-0000-0000-000000000001	Admin	devices	D	A
a2b4c7b9-34c1-4ea9-a158-59e4c9cde2a6	00000000-0000-0000-0000-000000000001	Admin	devices	R	A
745651e4-81e5-4640-a2c2-de003e71d3a1	00000000-0000-0000-0000-000000000001	Admin	devices	U	A
228b4866-395b-4c6a-8ff4-396c0c7bd200	00000000-0000-0000-0000-000000000001	Admin	iot_timeseries	C	A
9a7f1865-5992-45ee-b17f-1ccd303cbfa7	00000000-0000-0000-0000-000000000001	Admin	iot_timeseries	D	A
54419155-f0e4-496d-aed5-ff74179e0102	00000000-0000-0000-0000-000000000001	Admin	iot_timeseries	R	A
4f9f9c8b-558d-44de-bd94-b75ec5e45963	00000000-0000-0000-0000-000000000001	Admin	iot_timeseries	U	A
418085fa-514e-4634-8810-f454c2f735f1	00000000-0000-0000-0000-000000000001	Admin	resident_caregivers	C	A
f7c6d0b0-34da-4a25-ad1e-5646a76b6754	00000000-0000-0000-0000-000000000001	Admin	resident_caregivers	D	A
d77bf882-635c-4abd-b285-15be496f68a0	00000000-0000-0000-0000-000000000001	Admin	resident_caregivers	R	A
6611049b-7150-4278-b54a-29f9c8ffb813	00000000-0000-0000-0000-000000000001	Admin	resident_caregivers	U	A
89770a9b-f8b4-48fb-a2a1-51e3d304852e	00000000-0000-0000-0000-000000000001	Admin	resident_contacts	C	A
af8aeca0-3129-4008-9b91-a98d700f7fac	00000000-0000-0000-0000-000000000001	Admin	resident_contacts	D	A
1d059313-7616-4bcb-9bba-66ea6c9367c9	00000000-0000-0000-0000-000000000001	Admin	resident_contacts	R	A
3b1fc860-7ea5-44f7-ad4d-1bb9c1d9d517	00000000-0000-0000-0000-000000000001	Admin	resident_contacts	U	A
8155dcef-a0cd-4ec1-b07b-595be3c95ad7	00000000-0000-0000-0000-000000000001	Admin	resident_phi	C	A
198669df-26d7-44cc-b76b-ecd009f3580c	00000000-0000-0000-0000-000000000001	Admin	resident_phi	D	A
c4d70835-ed12-47e9-a825-d13e4632ab39	00000000-0000-0000-0000-000000000001	Admin	resident_phi	R	A
f82d078e-4bf5-48c7-8777-a52c017f9b41	00000000-0000-0000-0000-000000000001	Admin	resident_phi	U	A
56263c1e-4fb2-4126-b5d6-efefd17695da	00000000-0000-0000-0000-000000000001	Admin	residents	C	A
f059e23c-2aba-45a5-94a0-c651f62831a1	00000000-0000-0000-0000-000000000001	Admin	residents	D	A
7bb7bbaf-9886-4f6f-9678-0f4fd1d9942c	00000000-0000-0000-0000-000000000001	Admin	residents	R	A
b8bd6f83-c324-48ef-9ac5-ba7ccad3b04a	00000000-0000-0000-0000-000000000001	Admin	residents	U	A
8d4e1a3f-9e8d-45df-a6f0-adc081a7d77c	00000000-0000-0000-0000-000000000001	Admin	roles	R	A
e85104a9-e4f4-4148-8631-b81c11600fec	00000000-0000-0000-0000-000000000001	Admin	roles	U	A
a7d4be1e-a24a-4f6e-97c8-4391a7eecf7e	00000000-0000-0000-0000-000000000001	Admin	rooms	C	A
cade6f05-b56c-4d4a-8e24-a9fc38878df0	00000000-0000-0000-0000-000000000001	Admin	rooms	D	A
7bb0f35b-8805-4fef-a66e-824d0cdb1777	00000000-0000-0000-0000-000000000001	Admin	rooms	R	A
f551692d-4746-41d2-b4a1-985424e8131d	00000000-0000-0000-0000-000000000001	Admin	rooms	U	A
e949bba6-ec74-47b1-883c-d9fd04b31a51	00000000-0000-0000-0000-000000000001	Admin	round_details	C	A
fde687b3-f937-4f80-8867-54e57baa94ae	00000000-0000-0000-0000-000000000001	Admin	round_details	D	A
e9dff61b-1644-4ba7-ba42-de16e417062b	00000000-0000-0000-0000-000000000001	Admin	round_details	R	A
e3325557-cf87-4ac5-b350-fd83db706976	00000000-0000-0000-0000-000000000001	Admin	round_details	U	A
86c4a274-4fcf-48fe-ac0e-538ad79003b3	00000000-0000-0000-0000-000000000001	Admin	rounds	C	A
632a262a-2c99-476c-ab0d-1b43ea3f5324	00000000-0000-0000-0000-000000000001	Admin	rounds	D	A
57d1dad0-a39a-4075-97a1-b61335dd7fc5	00000000-0000-0000-0000-000000000001	Admin	rounds	R	A
726cfb51-d6f7-4c73-be81-9e8482d67de4	00000000-0000-0000-0000-000000000001	Admin	rounds	U	A
82466eb6-47c3-4fb0-885b-79117f5b3736	00000000-0000-0000-0000-000000000001	Admin	service_levels	C	A
2a8697aa-eccd-40a0-9d88-23d1bfa6dd91	00000000-0000-0000-0000-000000000001	Admin	service_levels	D	A
11bbaf3a-fd2e-48c1-beb4-20b68fb09327	00000000-0000-0000-0000-000000000001	Admin	service_levels	R	A
2bd3374d-9b3a-4215-a072-64369a36b496	00000000-0000-0000-0000-000000000001	Admin	service_levels	U	A
c51509f7-e190-4c81-a2f7-4299bbf78e4f	00000000-0000-0000-0000-000000000001	Admin	units	C	A
cfe670da-a701-4544-93bf-4e239b4fa24a	00000000-0000-0000-0000-000000000001	Admin	units	D	A
c0186a05-5184-485e-900c-e2785403d363	00000000-0000-0000-0000-000000000001	Admin	units	R	A
c1972c31-9110-4726-9325-23c100e42641	00000000-0000-0000-0000-000000000001	Admin	units	U	A
ce372a21-cfc8-41f1-aa12-4213eb98849f	00000000-0000-0000-0000-000000000001	Admin	users	C	A
244ebf50-0514-4e35-9ee6-4b3fc72b6bdf	00000000-0000-0000-0000-000000000001	Admin	users	D	A
19062aff-725d-4a43-967f-1953b3486caf	00000000-0000-0000-0000-000000000001	Admin	users	R	A
7d275c25-903c-4aef-bd85-56e4e0879589	00000000-0000-0000-0000-000000000001	Admin	users	U	A
bb860705-ae8f-4224-80d6-63c4b9780326	00000000-0000-0000-0000-000000000001	Admin	branches	R	A
404214d6-59a0-4e29-938e-63725ef7bf28	00000000-0000-0000-0000-000000000001	Admin	branches	C	A
c64b25d9-be02-408e-9d87-0c9fdb8715d3	00000000-0000-0000-0000-000000000001	Admin	branches	U	A
c5936209-e422-470b-b8e5-7f55925cffc7	00000000-0000-0000-0000-000000000001	SystemOperator	tenants	R	A
34102f84-4e20-410c-99f0-0b96bf2e882c	00000000-0000-0000-0000-000000000001	SystemOperator	tenants	C	A
a899c88f-7583-4bf8-8512-780db18175df	00000000-0000-0000-0000-000000000001	SystemOperator	tenants	U	A
4847ed04-0035-4afa-9997-298fbe831943	00000000-0000-0000-0000-000000000001	SystemOperator	tenants	D	A
180f9896-05c2-4685-b951-80158b5409bc	00000000-0000-0000-0000-000000000001	SystemOperator	device_store	R	A
421bfa92-6f4b-4ad5-81af-fb82824c578c	00000000-0000-0000-0000-000000000001	SystemOperator	device_store	C	A
b035996f-44e0-4f6c-9920-d12658b287aa	00000000-0000-0000-0000-000000000001	SystemOperator	device_store	U	A
e84ce415-2893-4d70-a435-072681e25bb6	00000000-0000-0000-0000-000000000001	SystemOperator	device_store	D	A
13694e4c-a7f7-4c47-8d47-128680abd9bd	00000000-0000-0000-0000-000000000001	SystemOperator	alarm_cloud	R	A
cd4d8399-bd5f-4e3c-96be-44d654bd14a6	00000000-0000-0000-0000-000000000001	SystemOperator	alarm_cloud	C	A
407c303a-499e-4a82-b7bd-93db7b3e8ab1	00000000-0000-0000-0000-000000000001	SystemOperator	alarm_cloud	U	A
68b2f794-20aa-415f-b738-f9ad63d28b5f	00000000-0000-0000-0000-000000000001	SystemOperator	alarm_cloud	D	A
72b37039-99e0-419b-8955-506aa3331f20	00000000-0000-0000-0000-000000000001	Manager	alarm_cloud	R	B
36aa2208-c6a0-48cd-b568-97a1ca607f3e	00000000-0000-0000-0000-000000000001	Admin	branches	D	A
f54b53ba-48f8-45bf-b7ad-3dcdb7a4ce60	00000000-0000-0000-0000-000000000001	Manager	alarm_cloud	U	B
b3467246-68e9-48ad-9bab-a670c1844df0	00000000-0000-0000-0000-000000000001	Manager	alarm_device	C	B
9330567c-784b-40a9-9612-3f6dd3a0e2aa	00000000-0000-0000-0000-000000000001	Manager	alarm_device	D	B
8d7f3a27-fb1d-47ce-a188-7f7c567ed80c	00000000-0000-0000-0000-000000000001	Manager	alarm_device	R	B
c5708b36-fd89-4764-a70e-c6026cc77420	00000000-0000-0000-0000-000000000001	Manager	alarm_device	U	B
59841045-320b-4c30-8f1c-7db41b3f54a6	00000000-0000-0000-0000-000000000001	Manager	alarm_events	C	B
ff1a2e1e-6a78-440e-87df-e7103cf88730	00000000-0000-0000-0000-000000000001	Manager	alarm_events	D	B
4d187015-98b2-4bb6-ac0b-93b706afebb9	00000000-0000-0000-0000-000000000001	Manager	alarm_events	R	B
89b5c275-12a2-4b40-b567-c57dc8fa1c24	00000000-0000-0000-0000-000000000001	Manager	alarm_events	U	B
bfd9bdeb-1bdb-4e47-80dd-7148a22f504b	00000000-0000-0000-0000-000000000001	Manager	beds	C	B
8e4dba14-7564-4a38-a744-e4d13aecd524	00000000-0000-0000-0000-000000000001	Manager	beds	D	B
d71315ba-c5c8-44a3-906a-e0999633d91b	00000000-0000-0000-0000-000000000001	Manager	beds	R	B
7e7c6b18-b544-41e3-b6c4-6a6019ed0129	00000000-0000-0000-0000-000000000001	Manager	beds	U	B
8f4a9ad0-a21c-4d5a-9f1c-22e3de56d46a	00000000-0000-0000-0000-000000000001	Manager	cards	R	B
691f1161-95ff-41f1-b258-eaab99825e3d	00000000-0000-0000-0000-000000000001	Manager	device_store	R	B
7a3ccfe9-ecf1-46d3-8871-8a1a3f02de6b	00000000-0000-0000-0000-000000000001	Manager	devices	C	B
fb050432-e750-4367-acb8-85e0e5af287d	00000000-0000-0000-0000-000000000001	Manager	devices	D	B
159e6ec9-806f-4687-b02f-9320b723a098	00000000-0000-0000-0000-000000000001	Manager	devices	R	B
9f2fb7f8-207f-44da-b0fd-5cbecdb121de	00000000-0000-0000-0000-000000000001	Manager	devices	U	B
4add8862-31ee-4336-9c76-1c67d7d712ab	00000000-0000-0000-0000-000000000001	Manager	iot_timeseries	R	B
7616af87-1f9d-4c23-9baf-bc322cdb22d8	00000000-0000-0000-0000-000000000001	Manager	resident_caregivers	C	B
0a310129-dd66-4b14-a9b2-714282ad2cc3	00000000-0000-0000-0000-000000000001	Manager	resident_caregivers	D	B
be2eaf8d-5f74-446c-92c5-d7a14a460f34	00000000-0000-0000-0000-000000000001	Manager	resident_caregivers	R	B
b7a2a26f-a0e7-4661-ba56-4b7d686f82be	00000000-0000-0000-0000-000000000001	Manager	resident_caregivers	U	B
51c8c23a-f232-4b63-8610-9997666dfff7	00000000-0000-0000-0000-000000000001	Manager	resident_contacts	C	B
188d540a-1e47-4946-9daf-5f69b87bc3d0	00000000-0000-0000-0000-000000000001	Manager	resident_contacts	D	B
5a1bc793-0f2d-4359-8299-3b428c05f757	00000000-0000-0000-0000-000000000001	Manager	resident_contacts	R	B
01608475-0e74-4ac2-b68e-67ab6c51d7e0	00000000-0000-0000-0000-000000000001	Manager	resident_contacts	U	B
d68e5d60-5340-45d0-a8f1-fc18b9830164	00000000-0000-0000-0000-000000000001	Manager	resident_phi	C	B
28fa9c9a-49c2-409a-bdc4-82de5b6390a5	00000000-0000-0000-0000-000000000001	Manager	resident_phi	D	B
2c521e09-f0b4-489c-af1d-60deec18fc71	00000000-0000-0000-0000-000000000001	Manager	resident_phi	R	B
82ac0ab1-0f79-4edd-8de8-965e52f4688a	00000000-0000-0000-0000-000000000001	Manager	resident_phi	U	B
86a1b7e9-3604-43fb-bafd-d813c1e1b15a	00000000-0000-0000-0000-000000000001	Manager	residents	C	B
946aeca2-6f26-4fc0-b682-3068d6555ebf	00000000-0000-0000-0000-000000000001	Manager	residents	D	B
69c0720a-4ad8-4dde-b065-a51f470358a7	00000000-0000-0000-0000-000000000001	Manager	residents	R	B
ce3ace0b-c3ce-4444-badf-877822821035	00000000-0000-0000-0000-000000000001	Manager	residents	U	B
3f878953-3843-409e-a252-c631e33de3aa	00000000-0000-0000-0000-000000000001	Manager	roles	R	B
a316bf07-9a8c-4f9e-88a1-d19b38d2026f	00000000-0000-0000-0000-000000000001	Manager	roles	U	B
aed03673-8ffb-464f-a8dd-b2c18ccf3f59	00000000-0000-0000-0000-000000000001	Manager	rooms	C	B
cd9124a3-84ec-4fda-a061-87da592cfc1c	00000000-0000-0000-0000-000000000001	Manager	rooms	D	B
e3e092ce-7c96-4f30-8f51-e27bd6ab77d6	00000000-0000-0000-0000-000000000001	Manager	rooms	R	B
dc343810-bf53-4474-aae1-0b33b0de4901	00000000-0000-0000-0000-000000000001	Manager	rooms	U	B
a2a4da03-9b65-4bde-9ccc-552e365f1ced	00000000-0000-0000-0000-000000000001	Manager	round_details	C	B
abf6581d-8f45-4af7-8729-74fb9ac90bb6	00000000-0000-0000-0000-000000000001	Manager	round_details	D	B
73eeb2f0-f9a5-400f-a117-5aaa4c86e1ba	00000000-0000-0000-0000-000000000001	Manager	round_details	R	B
6696a28d-f6a5-443a-973b-23804539b3b7	00000000-0000-0000-0000-000000000001	Manager	round_details	U	B
fbe3f9cb-21b5-4383-a9d2-221c99262199	00000000-0000-0000-0000-000000000001	Manager	rounds	C	B
e1be4533-09ae-4fc4-a521-878b3a14ff05	00000000-0000-0000-0000-000000000001	Manager	rounds	D	B
dcf83ded-f219-48d5-8fad-e2f3d7bf0162	00000000-0000-0000-0000-000000000001	Manager	rounds	R	B
e9c8e38d-1972-4af0-a9bb-ce6f4b33222b	00000000-0000-0000-0000-000000000001	Manager	rounds	U	B
0d2849fd-9861-4a72-aad4-0f685ef79054	00000000-0000-0000-0000-000000000001	Manager	service_levels	C	B
9cadd5e7-55f3-4971-96fb-24435e34de34	00000000-0000-0000-0000-000000000001	Manager	service_levels	D	B
e067a2aa-f42f-4bb4-a19d-f31ebb6ff144	00000000-0000-0000-0000-000000000001	Manager	service_levels	R	B
5b1078fd-5280-4986-82d7-29479ea9f3d4	00000000-0000-0000-0000-000000000001	Manager	service_levels	U	B
013c5f10-9411-4469-9814-a6300aec2de2	00000000-0000-0000-0000-000000000001	Manager	units	C	B
cd5cd990-2ac5-41c7-8c07-2902a07cd9db	00000000-0000-0000-0000-000000000001	Manager	units	D	B
92434604-a457-44c7-ba03-9946d412354f	00000000-0000-0000-0000-000000000001	Manager	units	R	B
179c08bc-16c5-4da2-bad2-0b042e7d7d56	00000000-0000-0000-0000-000000000001	Manager	units	U	B
51c7cca4-f82a-4d9d-9ccc-5e9669259a70	00000000-0000-0000-0000-000000000001	Manager	users	C	B
36f78abf-ad35-414a-80e3-99491f3739c0	00000000-0000-0000-0000-000000000001	Manager	users	D	B
2adbd6df-7692-4177-8467-70463c41bfe2	00000000-0000-0000-0000-000000000001	Manager	users	R	B
80b093a9-68a0-4013-9ac5-fed8ad6f002d	00000000-0000-0000-0000-000000000001	Manager	users	U	B
570c7d0f-279c-471a-b812-11da72b6d085	00000000-0000-0000-0000-000000000001	Manager	branches	R	B
a3932e74-a9cc-4694-96ee-a39dadd3fc95	00000000-0000-0000-0000-000000000001	Resident	alarm_cloud	R	A
27e5922b-879e-4392-a570-06d350e653be	00000000-0000-0000-0000-000000000001	IT	roles	R	A
2314d301-2478-4b0c-95e6-2a48f7821097	00000000-0000-0000-0000-000000000001	IT	users	R	A
0df176d2-3a9c-4a45-bd58-9fdb1988a069	00000000-0000-0000-0000-000000000001	IT	users	C	A
6ab88190-749f-4a1a-94c4-3434490dc053	00000000-0000-0000-0000-000000000001	IT	users	U	A
07eead86-4ba2-4321-b39e-c4960088ff12	00000000-0000-0000-0000-000000000001	IT	users	D	A
55eaa98b-8605-4e4a-9cc7-a19e1cae55cb	00000000-0000-0000-0000-000000000001	IT	units	R	A
7d42bb05-5db2-40e9-ace7-fa16cf4e03d9	00000000-0000-0000-0000-000000000001	IT	units	C	A
470e1536-d2e0-4317-bdf2-a38cdb8ce869	00000000-0000-0000-0000-000000000001	IT	units	U	A
54dc143e-90b3-4a3d-9abb-cee16ed1489f	00000000-0000-0000-0000-000000000001	IT	units	D	A
60fc62cd-9d36-4ef6-b646-c3564f312456	00000000-0000-0000-0000-000000000001	IT	rooms	R	A
2ff8c94d-cc9f-4ef0-9110-db8be45b9914	00000000-0000-0000-0000-000000000001	IT	rooms	C	A
fd7df188-75f6-4801-bcbf-64aa5934824c	00000000-0000-0000-0000-000000000001	IT	rooms	U	A
0f440139-322a-43b7-88b6-6c751899e208	00000000-0000-0000-0000-000000000001	IT	rooms	D	A
e5bfee28-71fe-4c68-a5b4-0eefd20ea339	00000000-0000-0000-0000-000000000001	IT	beds	R	A
c201b1b3-497c-446d-9356-de25a17bfc88	00000000-0000-0000-0000-000000000001	IT	beds	C	A
2221d8a4-d340-47c1-8ca0-d67556c989f7	00000000-0000-0000-0000-000000000001	IT	beds	U	A
fef6ebbc-c980-443c-80e8-dcec82789b7e	00000000-0000-0000-0000-000000000001	IT	beds	D	A
af91b942-e59d-4e52-9b56-504bbe370220	00000000-0000-0000-0000-000000000001	IT	residents	R	A
05a77763-f05e-4fb4-a8b3-60b73239ca3d	00000000-0000-0000-0000-000000000001	IT	resident_caregivers	R	A
55af24ec-950e-4c3f-8754-60c7d17e0626	00000000-0000-0000-0000-000000000001	IT	devices	R	A
7c91362c-2b41-4ed6-9109-8dbb28126a11	00000000-0000-0000-0000-000000000001	IT	devices	C	A
fb473fed-f79c-4202-a668-ec80e4e6159d	00000000-0000-0000-0000-000000000001	IT	devices	U	A
4b7b63ca-ba3b-40c7-8bf7-786cd01f7644	00000000-0000-0000-0000-000000000001	IT	devices	D	A
cd5b4e93-69d2-464e-b813-4c111c1ba521	00000000-0000-0000-0000-000000000001	IT	device_store	R	S
91cef39a-7248-4b23-96a4-3324cbf02934	00000000-0000-0000-0000-000000000001	IT	alarm_events	R	A
0d0ee3af-28ac-4f80-a83a-ed3416ec93cd	00000000-0000-0000-0000-000000000001	IT	alarm_device	R	A
14c26bc7-75ac-4dcd-84c1-8ff507fb68f8	00000000-0000-0000-0000-000000000001	IT	alarm_device	C	A
40e20aa8-4ec6-477e-a795-71929ca331a9	00000000-0000-0000-0000-000000000001	IT	alarm_device	U	A
617f4456-94b4-4907-b324-01bc2d08f26a	00000000-0000-0000-0000-000000000001	IT	alarm_device	D	A
277fefbd-59eb-4db2-82c9-2a5d5ed8b75a	00000000-0000-0000-0000-000000000001	IT	config_versions	R	A
16305d0f-65fe-43f6-ada4-d035d1382ad9	00000000-0000-0000-0000-000000000001	IT	config_versions	C	A
2bff7f51-e723-4312-b0c6-196dcc404591	00000000-0000-0000-0000-000000000001	Individual	alarm_cloud	R	A
2596ac89-3799-4c32-8900-dfa82f3e8594	00000000-0000-0000-0000-000000000001	IT	config_versions	U	A
09001d58-fcc0-4918-8045-5ddf02b06798	00000000-0000-0000-0000-000000000001	IT	config_versions	D	A
8f5e969d-d5fa-45bd-baa3-46978031fbdf	00000000-0000-0000-0000-000000000001	SystemAdmin	branches	R	A
61009bd7-285c-4090-ab3b-da60fc0939ec	00000000-0000-0000-0000-000000000001	SystemAdmin	branches	C	A
ec608f4a-eb1d-49f4-9f00-787f23b5c9d5	00000000-0000-0000-0000-000000000001	SystemAdmin	branches	U	A
bee2d3cc-8930-45fd-8982-e36a32b45ad1	00000000-0000-0000-0000-000000000001	SystemAdmin	branches	D	A
11b66707-5308-4604-9f34-ee16d4511ab7	00000000-0000-0000-0000-000000000001	Nurse	units	R	A
db983b41-ddca-4afd-9f00-69228a2ca113	00000000-0000-0000-0000-000000000001	Nurse	rooms	R	A
89bbf9c0-ffc9-4195-9e95-5113d062666f	00000000-0000-0000-0000-000000000001	Nurse	beds	R	A
36d39c60-96f5-4807-8f72-2e79aa326e28	00000000-0000-0000-0000-000000000001	Nurse	residents	R	S
34a25489-ee9f-4756-b438-8c670a67454c	00000000-0000-0000-0000-000000000001	Nurse	resident_phi	R	S
b91dace8-7e96-447e-82b0-c1dcb04432c0	00000000-0000-0000-0000-000000000001	Nurse	resident_contacts	R	S
3ba081ed-d91f-498e-adfa-0fb2067ee6b5	00000000-0000-0000-0000-000000000001	Nurse	resident_caregivers	R	A
32cb1866-1582-4ef5-b942-15dd360181af	00000000-0000-0000-0000-000000000001	Nurse	devices	R	A
3cabbb6f-e60a-48f0-b18e-f5f3206cf396	00000000-0000-0000-0000-000000000001	Nurse	alarm_events	R	A
7e716125-9589-4e6e-85a3-6487abd9b7a8	00000000-0000-0000-0000-000000000001	Nurse	alarm_events	U	S
f3aa7378-8246-4767-a050-66080df49009	00000000-0000-0000-0000-000000000001	Nurse	alarm_device	R	A
7ce298ad-c50c-4a73-847e-16840f376c19	00000000-0000-0000-0000-000000000001	Nurse	alarm_device	C	S
8be357dd-7b31-43b1-9411-a7cbb35e44a9	00000000-0000-0000-0000-000000000001	Nurse	alarm_device	U	S
a9430b29-afa5-4ce3-841e-3b4c015dfe33	00000000-0000-0000-0000-000000000001	Nurse	alarm_cloud	R	A
6613696f-47f7-48be-86cf-3708b144ece0	00000000-0000-0000-0000-000000000001	Nurse	service_levels	R	A
8685306f-f788-4933-b862-4886ea66faa6	00000000-0000-0000-0000-000000000001	Nurse	cards	R	A
af339722-9b21-4d41-bcc6-86e16f151ff0	00000000-0000-0000-0000-000000000001	Nurse	rounds	R	A
1a1324d7-425a-4b19-a605-c738ff3f63cf	00000000-0000-0000-0000-000000000001	Nurse	rounds	U	S
f893a424-2f02-4829-ac67-6f01b2fe6351	00000000-0000-0000-0000-000000000001	Nurse	round_details	R	A
b340572d-263b-44c1-a9af-6c3b2c4f3ac5	00000000-0000-0000-0000-000000000001	Nurse	round_details	U	S
ba73166a-bc94-4638-927d-b607dd986de4	00000000-0000-0000-0000-000000000001	Caregiver	units	R	A
a19c3246-a841-47eb-aa64-145db2181ac8	00000000-0000-0000-0000-000000000001	Caregiver	rooms	R	A
3562407f-0d26-468c-9536-1f78dc556f51	00000000-0000-0000-0000-000000000001	Caregiver	beds	R	A
5704f51d-c91b-4187-92f2-0605db8329f1	00000000-0000-0000-0000-000000000001	Caregiver	residents	R	S
f42be4a5-df11-4aba-a0ef-3c08ee5bade0	00000000-0000-0000-0000-000000000001	Caregiver	resident_phi	R	S
1785569c-a132-4054-b59a-f8ce97a01034	00000000-0000-0000-0000-000000000001	Caregiver	resident_contacts	R	S
703622ac-f7f3-4723-b678-7c252fb53fd3	00000000-0000-0000-0000-000000000001	Caregiver	resident_caregivers	R	A
8511bbd0-c163-4681-85cb-056dd5d2b8db	00000000-0000-0000-0000-000000000001	Caregiver	devices	R	A
c6ed1107-7e44-46e5-9347-61ee3e5f8c4b	00000000-0000-0000-0000-000000000001	Caregiver	alarm_events	R	S
cadb5476-9d65-4b6b-bc90-e38f9ab2f47d	00000000-0000-0000-0000-000000000001	Caregiver	alarm_device	R	S
35be5b00-2aa7-4711-ab42-9dee4f2f7ca3	00000000-0000-0000-0000-000000000001	Caregiver	alarm_cloud	R	A
acf9d30f-d8a6-4bee-aeac-463a54d345a4	00000000-0000-0000-0000-000000000001	Caregiver	service_levels	R	A
ca88b98e-a070-4b5e-9d77-3b20ae500b92	00000000-0000-0000-0000-000000000001	Caregiver	rounds	R	S
626775c7-101d-4d6b-8059-1143012828d6	00000000-0000-0000-0000-000000000001	Caregiver	rounds	U	S
690c1d95-f6e0-43a2-933d-ffb722df69e9	00000000-0000-0000-0000-000000000001	Caregiver	round_details	R	S
cfe9aaa4-7549-4a65-8262-1322a1ff673f	00000000-0000-0000-0000-000000000001	Caregiver	round_details	U	S
ade66544-6492-421e-92f5-b336ac04ac5e	00000000-0000-0000-0000-000000000001	Individual	resident_phi	R	S
a6107461-ba1b-4267-9d6e-43f2dc0d6fca	00000000-0000-0000-0000-000000000001	Individual	resident_phi	C	S
69a73fda-0866-4c69-8080-87dade690271	00000000-0000-0000-0000-000000000001	Individual	resident_phi	U	S
9ba10b0b-c421-4479-a59f-ca2965da7901	00000000-0000-0000-0000-000000000001	Individual	resident_contacts	R	S
3c378338-6bc8-4975-b759-d96b61a5452e	00000000-0000-0000-0000-000000000001	Individual	resident_contacts	C	S
988608b2-40a7-423e-956c-f3187e5b054e	00000000-0000-0000-0000-000000000001	Individual	resident_contacts	U	S
2a736198-5548-45e0-8e8c-5333e2a5af4b	00000000-0000-0000-0000-000000000001	Individual	resident_contacts	D	S
aad16d61-f7ee-4aa2-b945-57b3bd73e81a	00000000-0000-0000-0000-000000000001	Individual	resident_caregivers	R	S
1545591f-5bc3-41dc-9f16-d8691bf4d64c	00000000-0000-0000-0000-000000000001	Individual	devices	R	S
f44bf544-c3d4-4a81-ab04-180a50211571	00000000-0000-0000-0000-000000000001	Individual	alarm_events	R	S
70d96eef-d1e1-4fac-ada6-e8a70531e933	00000000-0000-0000-0000-000000000001	Individual	alarm_events	U	S
7e33a371-9314-4f2e-ab09-a69418e42670	00000000-0000-0000-0000-000000000001	Individual	alarm_device	R	S
752012b7-cc44-45f2-8710-df8e180e016f	00000000-0000-0000-0000-000000000001	Individual	alarm_device	U	S
310fae74-c1d3-4ec0-871a-efa21649846e	00000000-0000-0000-0000-000000000001	Individual	cards	R	S
fe42eb7e-7e11-497d-be97-70df55321996	00000000-0000-0000-0000-000000000001	Resident	alarm_events	R	S
24c900c0-4d06-49e5-9d52-1f7cf4d8d6f3	00000000-0000-0000-0000-000000000001	Resident	cards	R	S
589ab426-c6fc-4ee4-b847-b222b3865b56	00000000-0000-0000-0000-000000000001	SystemAdmin	tenants	R	A
6da57374-5309-4151-a709-fb04ea0d5a5a	00000000-0000-0000-0000-000000000001	SystemAdmin	tenants	C	A
1f50d618-c379-4223-844a-acfec20474aa	00000000-0000-0000-0000-000000000001	SystemAdmin	tenants	U	A
9b998763-ac30-46c3-a680-6be199e0ff4c	00000000-0000-0000-0000-000000000001	SystemAdmin	tenants	D	A
5ed26370-dc6e-4f24-8641-62cc5c047523	00000000-0000-0000-0000-000000000001	SystemAdmin	roles	R	A
0df37bec-a08c-410c-b743-0f41e2bc3e36	00000000-0000-0000-0000-000000000001	SystemAdmin	roles	C	A
d910e20c-1821-4b33-a0fa-521930420c4f	00000000-0000-0000-0000-000000000001	SystemAdmin	roles	U	A
90885db8-1df4-43d7-a59f-5d621b8ca099	00000000-0000-0000-0000-000000000001	SystemAdmin	roles	D	A
228e50ce-718a-415b-b59d-28fc66ea5da6	00000000-0000-0000-0000-000000000001	SystemAdmin	role_permissions	R	A
d22f5108-dd49-436a-b4e6-760e5928d018	00000000-0000-0000-0000-000000000001	SystemAdmin	role_permissions	C	A
d78cbd2a-e8e4-47d3-b5a8-659aa3fd3c0b	00000000-0000-0000-0000-000000000001	SystemAdmin	role_permissions	U	A
0e32745c-8d9d-4ebf-bafa-d2f79cca09ea	00000000-0000-0000-0000-000000000001	SystemAdmin	role_permissions	D	A
d141ed39-6dce-485a-b33e-05506e8c25a9	00000000-0000-0000-0000-000000000001	SystemAdmin	device_store	R	A
5bd4bc26-8ede-499d-bea3-b9c4a3f718f0	00000000-0000-0000-0000-000000000001	SystemAdmin	device_store	C	A
49fd0d46-0a93-4007-82b8-8c614608cce6	00000000-0000-0000-0000-000000000001	SystemAdmin	device_store	U	A
fe8bbe74-b9ce-4df1-a9e4-e031fb169ad7	00000000-0000-0000-0000-000000000001	SystemAdmin	device_store	D	A
e3f842f8-712f-4e16-84c2-a8c87120237e	00000000-0000-0000-0000-000000000001	SystemOperator	branches	R	A
b7229b17-451b-4979-8466-1e823c96f4db	00000000-0000-0000-0000-000000000001	SystemOperator	branches	C	A
4d309ed8-6a0e-434b-a5f4-a5ed1a7ebbe8	00000000-0000-0000-0000-000000000001	SystemOperator	branches	U	A
9e4d099b-2eed-4be7-8162-5fb7bbc08dcc	00000000-0000-0000-0000-000000000001	SystemOperator	branches	D	A
02dcab15-a7b5-451e-8259-27928cace39d	00000000-0000-0000-0000-000000000001	SystemAdmin	users	R	A
f74b565c-0fc8-466e-940f-159e906b86f8	00000000-0000-0000-0000-000000000001	SystemAdmin	users	C	A
e98ea14a-8a06-40c8-8a98-9a5b68da0752	00000000-0000-0000-0000-000000000001	SystemAdmin	users	U	A
bc2a7cdd-1c09-448d-9a22-cfcb86970da2	00000000-0000-0000-0000-000000000001	SystemAdmin	users	D	A
6103f142-6658-47d9-aa0e-c4da1b4eb08c	00000000-0000-0000-0000-000000000001	Caregiver	cards	R	A
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (role_id, tenant_id, role_code, description, is_system, is_active) FROM stdin;
c9ff5e45-f4f6-4567-a90f-f65b9a309718	00000000-0000-0000-0000-000000000001	SystemAdmin	System Administrator (Cross-Tenant)\nManage system-level resources (roles, role_permissions, device_store, tenants). Business data read-only.	t	t
97037c01-490e-4d87-a008-251b2d5d4ab8	00000000-0000-0000-0000-000000000001	SystemOperator	System Operator (Platform Ops)\nPlatform operations: manage tenants, device_store, alarm_cloud templates/config.	t	t
47ff2ad0-dac0-45bc-b94a-e187c6d8c241	00000000-0000-0000-0000-000000000001	Admin	Administrator\nFull resource management permissions.	t	t
d61a0ded-2c16-4a65-87f7-cae1d8e39cc8	00000000-0000-0000-0000-000000000001	IT	IT Support\nDevice management, Layout management, user account management, device configuration.	t	t
6945e405-ec45-44be-afdf-553632d25e31	00000000-0000-0000-0000-000000000001	Nurse	Nurse\nView assigned residents monitor, handle alarm event, set special alarm.	t	t
1a136de5-4450-4683-8873-4501acd9a6b9	00000000-0000-0000-0000-000000000001	Caregiver	Caregiver\nView assigned residents monitor, handle alarm event, set special alarm.	t	t
bf2e4eb9-37d5-4e92-ab46-0ff0217705d6	00000000-0000-0000-0000-000000000001	Resident	Resident\nView self wellness & safety, authorize emergency contact, special environment: handle self alarm event.	t	t
4e43d682-d761-4c4e-b1ed-84209228a013	00000000-0000-0000-0000-000000000001	Individual	Individual\nPersonal user (B2C), view own wellness & safety, handle own alarm event.	t	t
7d6e9cf6-ee85-4134-86b3-f4ce9edf135a	00000000-0000-0000-0000-000000000001	Manager	Manager of Branch\nExecutive Director / Facility Director of Branch\nBusiness management: Staff, Unit, Resident manager, Device, Alarm setting.\nApprove/disable Resident and Family account access of this branch.	t	t
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rooms (room_id, tenant_id, unit_id, room_name, layout_config) FROM stdin;
a8a03532-e213-48b0-87f1-eb00db32b6f5	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	d8b82a88-30c3-4c62-a7c5-c4d88d495619	bedroom	\N
472b2643-e4e7-40ac-bdae-0413aee8b1cd	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	d8b82a88-30c3-4c62-a7c5-c4d88d495619	bathroom	\N
258cde35-7065-483e-adde-8d7e1343ef3d	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	833c522b-7f8b-4415-8e2f-71a8f8c4dafc	bookroom	\N
4e7e5965-2af4-4a1f-91a1-b523e42de8e8	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	833c522b-7f8b-4415-8e2f-71a8f8c4dafc	bedroom	\N
d9166bc1-4387-4de1-955c-81445efec204	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	833c522b-7f8b-4415-8e2f-71a8f8c4dafc	bathroom	\N
51d7091e-bfb1-4d04-9994-fbd72b32a624	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	d8b82a88-30c3-4c62-a7c5-c4d88d495619	E101	\N
02930aec-32ea-4379-b14e-e9f17fffe599	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	0afa6fc6-df74-4931-8615-e6af3bfeecee	bookroom	\N
\.


--
-- Data for Name: round_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.round_details (detail_id, tenant_id, round_id, resident_id, bed_id, unit_id, bed_status, sleep_state_snomed_code, sleep_state_display, heart_rate, respiratory_rate, posture_snomed_code, posture_display, data_timestamp, notes) FROM stdin;
\.


--
-- Data for Name: rounds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rounds (round_id, tenant_id, round_type, unit_id, executor_id, round_time, notes, status) FROM stdin;
\.


--
-- Data for Name: service_levels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_levels (level_code, description, color, color_hex, priority) FROM stdin;
Independent	Independent living, able to perform daily activities without assistance	green	#28a745	1
Assisted	Requires partial assistance with daily activities, but can complete some activities independently	blue	#007bff	2
MemoryCare	Requires cognitive support, may need memory aids and reminders	yellow	#ffc107	3
FallRisk	Fall risk, requires fall prevention and monitoring, may need assistive devices	orange	#fd7e14	4
VitalRisk	Vital signs risk, abnormal heart rate or breathing, requires close monitoring and medical intervention	red	#dc3545	5
Critical	Critical condition, requires 24-hour close monitoring and medical intervention, may need special care	red	#c82333	6
\.


--
-- Data for Name: sleepace_report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sleepace_report (report_id, tenant_id, device_id, device_code, record_count, start_time, end_time, date, stop_mode, time_step, timezone, sleep_state, report, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: snomed_mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.snomed_mapping (mapping_id, mapping_type, source_value, snomed_code, snomed_display, category, loinc_code, display_en, firmware_version, duration_threshold_minutes) FROM stdin;
f032fb0e-8c30-48d5-ba20-93e53da56fc7	posture	0	\N	Initialization	activity	\N	Initialization	\N	\N
9f09bc30-2170-4826-89a6-d2301fc8d9ab	posture	1	129006008	Walking	activity	68461-1	Walking	\N	\N
985433a1-b076-4a4b-8b74-34b3a225eac1	posture	2	129839007	At risk for falls	safety	\N	At risk for falls	\N	\N
f6f41572-1d59-4772-beb8-26c575ee5efa	posture	3	402120000	Sitting position	activity	56903-8	Sitting position	\N	\N
d69a8bfc-f6c1-4c9f-a437-0acc56eab23b	posture	4	383370001	Standing position	activity	56903-8	Standing position	\N	\N
d89fe0e9-ddf4-445d-8c21-3a487929f9d0	posture	5	161898004	Fall	safety	\N	Fall	\N	\N
e93e81ad-09fe-49ac-8da6-11396161de86	posture	6	109030009	Lying position	activity	56903-8	Lying position	202406	\N
a8ec81e6-d086-4bd3-b9d4-2b5977ffdc94	posture	7	129839007	At risk for falls	safety	\N	At risk for falls	202407	\N
3ce2fda1-fcf9-4b34-9b65-3d1719152924	posture	8	161898004	Fall	safety	\N	Fall	202407	\N
d92fe306-caae-4251-b040-989c6611e196	posture	9	109030009	Lying position	activity	56903-8	Lying position	202501	\N
b8ddecf5-5e15-42ae-a0d0-9392c7b46476	posture	10	129839007	At risk for falls	safety	\N	At risk for falls	202501	\N
15702016-bc94-47da-b328-5068f851e5e5	posture	11	161898004	Fall	safety	\N	Fall	202501	\N
3f40eedc-5613-4b2c-9454-9b64a67f116c	event	NO_EVENT	\N	No event	activity	\N	No event	\N	\N
fbcb1774-383e-4434-9c1c-e939355d01cc	event	ENTER_ROOM	\N	Enter room	activity	\N	Enter room	\N	\N
cdb329e0-499e-4d90-84e2-6d0a51990e11	event	LEAVE_ROOM	\N	Leave room	activity	\N	Leave room	\N	\N
11149be1-8aca-43ee-b282-e48b99221b67	event	ENTER_AREA	\N	Enter area	activity	\N	Enter area	\N	\N
ec47aa20-a9f6-430c-bf2f-6d9e0a052552	event	LEAVE_AREA	\N	Leave area	activity	\N	Leave area	\N	\N
5236d363-a774-44b2-944d-1a9271234801	event	LEFT_BED	248570008	Not in bed	activity	\N	Left bed	\N	\N
8a07ff1f-268a-4fba-8a81-1e2966c3341a	event	ENTER_BED	248569007	In bed	activity	\N	Enter bed	\N	\N
98fa3992-cd52-4022-a6f6-c36f544de3c5	event	BED_SIT_UP	40199007	Bed sitting position	activity	\N	Bed sit up	\N	\N
ee373b76-8234-4a00-bf77-4fcbe2b2e42e	event	WANDERING	129838004	Wandering behavior	behavioral	\N	Wandering	\N	\N
531a6aa6-889b-4174-8596-e4547e032a0b	event	NO_TURNING_2H	248527007	Lack of change in body position	behavioral	\N	No turning for 2H	\N	120
ee1f8b9b-7dda-449a-9865-193cdfdd3e5d	event	NO_BODY_MOVEMENT_2H	260413007	No movement	behavioral	\N	No body movement for 2H	\N	120
e685b909-d3bd-437d-a3e3-252ab6da6e86	event	WALKING	229065009	Walking	activity	\N	Walking	\N	\N
2301ad6d-ae84-4d77-855f-4dbde440253a	event	STILL	248257009	Still	activity	\N	Still	\N	\N
f95a4701-4b1d-433d-90b0-c40c832b6ea3	event	HEART_RATE	364075005	Heart rate	vital-signs	\N	Heart Rate (HR)	\N	\N
6beabbb4-6b64-4fc8-9285-9517d24a695f	event	RESPIRATORY_RATE	86290005	Respiratory rate	vital-signs	\N	Respiratory Rate (RR)	\N	\N
cf0df9c2-757b-4322-b44b-8df6cc5dfd34	event	APNEA_CONFIRMED	67905006	Apnea	clinical	\N	Apnea	\N	\N
1c647585-c2bb-4b23-b4e2-dabbcd8ed239	event	BRADYCARDIA	342400002	Bradycardia	clinical	\N	Bradycardia	\N	\N
6aa2990b-6e86-46fc-911e-6e2071f7c20e	event	TACHYCARDIA	271636001	Tachycardia	clinical	\N	Tachycardia	\N	\N
2eb8971a-bf64-458e-824c-dec3808a85d7	event	ABNORMAL_HEART_RATE	364400009	Abnormal heart rate	clinical	\N	Abnormal heart rate	\N	\N
666e4c76-4723-4711-ae5c-355cdbeee5ef	event	BRADYPNEA	301273002	Bradypnea	clinical	\N	Bradypnea	\N	\N
6e012460-6cbf-458e-942c-a4947bc0e4b8	event	TACHYPNEA	301279008	Tachypnea	clinical	\N	Tachypnea	\N	\N
9e42da29-66de-4f2e-a076-ae5f59b831bf	event	AWAKE	248220002	Awake	activity	\N	Awake	\N	\N
d3cc8e69-bbd3-4c6a-a80d-4db328ee838c	event	LIGHT_SLEEP	248232005	Light sleep	activity	\N	Light sleep	\N	\N
830e72f4-30f5-40bd-9862-23e1f648fdfd	event	DEEP_SLEEP	248233000	Deep sleep	activity	\N	Deep sleep	\N	\N
7c826e1f-fb85-4172-87e0-2d1abd5ffe2d	event	FALL	161898004	Fall	safety	\N	Fall	\N	\N
4d1dfd86-666c-41a6-a24d-8dab27082bd1	event	FALL_SUSPECTED	129839007	At risk for falls	safety	\N	Suspected fall	\N	\N
ff9e2859-d959-486f-9411-43f68f11c01c	event	ON_FLOOR	161898004	Fall	safety	\N	On floor	\N	\N
6d689ace-2cc7-4847-8499-85ffa46cc45c	event	PROLONGED_STAY	424547005	Prolonged stay	safety	\N	Prolonged stay	\N	\N
9fc360bd-e7bf-4322-be3c-48f5433160e2	event	NO_ACTIVITY_24H	373147003	24-hour Inactivity	safety	\N	24H no activity	\N	\N
a50ca8ed-7b31-4117-a59f-fd26ff58bcd6	event	ABNORMAL_POSTURE	43029002	Abnormal posture	safety	\N	Abnormal posture	\N	\N
47570d2b-9906-4077-9569-ba80f95f7bf0	event	OFFLINE_ALARM	397942008	Device disconnection	device	\N	Device offline	\N	\N
9df70804-41bb-48f7-ba75-e0a8fc44cac3	event	DEVICE_FAILURE	282095001	Device failure	device	\N	Device failure	\N	\N
b6f57ec0-341e-4c60-a7d2-36545e29cdf7	event	LOW_BATTERY	703507001	Low battery power	device	\N	Low battery	\N	\N
0075ec6e-dfe5-4d72-8536-603e3ee3b807	event	DEVICE_CONFIG_FAILURE	4661009	Device configuration failure	device	\N	Device configuration failure	\N	\N
2fc8b313-e2e7-41f5-92f5-13b75ed4d3ad	event	ANGLE_EXCEPTION	781417007	Equipment malfunction	device	\N	Angle exception	\N	\N
0c71f5d6-ad88-4dc1-a8da-48b29b1c4b35	event	DEVICE_ONLINE	706689003	Device online	device	\N	Device online	\N	\N
eb2f86cd-f026-4ebb-a2c3-0781f1f0deef	event	DEVICE_RECOVERED	706689003	Device recovered	device	\N	Device recovered	\N	\N
44c03cdf-d9ef-4b71-994a-71b03cc1dbec	event	MULTIPLE_PERSONS	\N	Multiple persons	social-history	\N	Multiple persons	\N	\N
1fcc485f-7058-45a2-8f53-fa0b76e4ea34	event	PERSON_DISTANCE	\N	Person distance	activity	\N	Person distance	\N	\N
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (tenant_id, tenant_type, tenant_name, domain, email, phone, status, metadata) FROM stdin;
bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	organization	demo	demo.com	admin@demo.com	\N	active	{}
beefa852-9c2f-4641-8212-897d0f57c938	organization	sunset	sunset.com	admin@sunset.com	\N	active	{}
18842522-420e-467d-abc0-bfe91f320525	organization	b2c	b2c.com	admin@b2c.com	\N	deleted	{}
00000000-0000-0000-0000-000000000001	organization	System	system.local	\N	\N	active	\N
\.


--
-- Data for Name: units; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.units (unit_id, tenant_id, branch_id, unit_name, floor, layout_config, unit_type, is_public, is_shared_unit, timezone, building_id) FROM stdin;
1b93ac0b-b605-43db-a3d0-8c88fcd35be8	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	2f614eec-5bbc-492b-9f9b-8e1d22b14d2b	S201	2F	\N	Facility	f	f	America/Denver	ad49ccc1-2165-4ced-9774-fe4ae4ff6189
d8b82a88-30c3-4c62-a7c5-c4d88d495619	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	6b7bd97a-42e4-4086-8232-ecf7ae545eec	E101	1F	\N	Facility	f	t	America/Denver	528ebbf0-5657-4f77-a87d-f2523dfcdfd8
833c522b-7f8b-4415-8e2f-71a8f8c4dafc	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	6b7bd97a-42e4-4086-8232-ecf7ae545eec	E301	3F	\N	Facility	f	f	America/Denver	528ebbf0-5657-4f77-a87d-f2523dfcdfd8
4f09bbf5-a649-44be-8d13-2a163027a923	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	6b7bd97a-42e4-4086-8232-ecf7ae545eec	E102	1F	\N	Facility	f	t	America/Denver	528ebbf0-5657-4f77-a87d-f2523dfcdfd8
0afa6fc6-df74-4931-8615-e6af3bfeecee	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	6b7bd97a-42e4-4086-8232-ecf7ae545eec	B101	1F	\N	Facility	f	f	America/Denver	e090cb4b-6dd3-44ac-9cbc-a5121b2b255a
\.


--
-- Data for Name: user_branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_branches (user_branch_id, tenant_id, user_id, branch_id, is_primary) FROM stdin;
f26b4657-b21e-4313-8f11-05859f9bc84e	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	51948acc-18ba-4b0b-946a-308333b81e48	2f614eec-5bbc-492b-9f9b-8e1d22b14d2b	f
9e5a2b52-e88d-4078-9b51-3d1e2d5c87b5	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	6b589b3f-e0ad-46b2-88c4-434ad65081d9	6b7bd97a-42e4-4086-8232-ecf7ae545eec	t
1fc6e929-6459-4bbd-9db6-dd39f010487e	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	09345eff-b91b-46cc-97f5-c7321361f430	2f614eec-5bbc-492b-9f9b-8e1d22b14d2b	t
55a976e4-f6f7-4b78-9047-98ca016ade3e	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	029f6ad1-aaf5-4904-b430-e8e76e727718	6b7bd97a-42e4-4086-8232-ecf7ae545eec	f
f7864f40-6139-419f-a298-33982d12dd57	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	728f885e-5265-486f-b9e3-bb430a242220	2f614eec-5bbc-492b-9f9b-8e1d22b14d2b	t
5e796feb-a622-4d03-8ab9-16c6121d1c5c	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	98bbfd27-a342-46b2-9fa1-6d859940a50c	2f614eec-5bbc-492b-9f9b-8e1d22b14d2b	t
fc70e4fc-d41a-4d7d-9b8e-100acbe303e6	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	1e5616e3-3739-4835-8d95-afb4a3933ab6	6b7bd97a-42e4-4086-8232-ecf7ae545eec	t
84eb20e9-99ce-4fd1-a935-06a8db3e81c9	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	c3b9bde2-4be4-4671-af81-f79694486932	6b7bd97a-42e4-4086-8232-ecf7ae545eec	f
79db4aa9-fdb8-4fcf-8b1d-f33a3e1a7122	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	571f6e61-d841-4822-9f76-1987abe3666a	6b7bd97a-42e4-4086-8232-ecf7ae545eec	t
5d7be014-da87-49d8-9b63-1e8df8e89276	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	51948acc-18ba-4b0b-946a-308333b81e48	6b7bd97a-42e4-4086-8232-ecf7ae545eec	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (user_id, tenant_id, user_account, user_account_hash, nickname, email, phone, email_hash, phone_hash, password_hash, pin_hash, role, status, alarm_levels, alarm_channels, alarm_scope, last_login_at, user_tags, preferences) FROM stdin;
287b46e3-5ecd-4559-8558-afa9f8845ee2	00000000-0000-0000-0000-000000000001	sysadmin	\\xd577adc54e95f42f15de2e7c134669888b7d6fb74df97bd62cb4f5b73c281db4	SystemAdmin	\N	\N	\N	\N	\\x9a4aabf0e5cf71cae2cea646613ce7e2a5919fa758e56819704be25a3a2c1f0b	\N	SystemAdmin	active	\N	\N	\N	2026-01-03 02:34:57.620001+00	\N	{}
51948acc-18ba-4b0b-946a-308333b81e48	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	admin	\\x8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918	Admin	\N	\N	\N	\N	\\x9a4aabf0e5cf71cae2cea646613ce7e2a5919fa758e56819704be25a3a2c1f0b	\\x03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4	Admin	active	\N	\N	ALL	2026-01-09 06:51:14.420698+00	[]	{"vitalFocus": {"selectedCardIds": []}}
09345eff-b91b-46cc-97f5-c7321361f430	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	m2	\\x29c1b289e7522195b362e44f54e05470b69ad20540ab60a18a05e5bf6951f13d	m2	m2@demo.com	\N	\\xceefbb71964cce36f09350d97855aebd2f0ebf2aeb43eda85c6005784207fde5	\N	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	\\x03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4	Manager	active	{0,4}	{EMAIL,SMS}	BRANCH	2025-12-31 07:04:01.242884+00	\N	{}
029f6ad1-aaf5-4904-b430-e8e76e727718	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	n1	\\x676b8bb84ce7267dd520deca4811c8f10a53e636352f06987f42fe425acedd80	N1	n1@demo.com	\N	\\xd0585b0c1687f26a79970e8379be27fb2ee001d33514c3859e0c27da480e8033	\N	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	\\x03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4	Nurse	active	{0,4}	{EMAIL,SMS}	ASSIGNED_ONLY	2025-12-31 04:51:20.988053+00	["EastST", "Memory"]	{}
98bbfd27-a342-46b2-9fa1-6d859940a50c	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	n2	\\x0480a93d2e9b094b89e08e01976089ac18193af802c66b631cc8d2dc1bae8c88	n2	\N	\N	\N	\N	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	\\x03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4	Nurse	active	{0,4}	{EMAIL,SMS}	ASSIGNED_ONLY	\N	["NightShift"]	{}
571f6e61-d841-4822-9f76-1987abe3666a	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	n11	\\x93c6cdd33a610f6c0c4372d7450a80dc03745b214a704bd257392c1e8b3043f4	n11-back	n11@demo.com	\N	\\x1bec715fc21d96069509bf8cc96153cfd3998cf8af552ff2c91bb58579af1e75	\N	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	\\x03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4	Nurse	active	{0,4}	{EMAIL,SMS}	ASSIGNED_ONLY	\N	["HotBack"]	{}
1e5616e3-3739-4835-8d95-afb4a3933ab6	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	c11	\\xf4baf901d1b9fcc11a9d3c714fda524455a9875aececc7a30b202a058bc696e6	C1_back	c11@demo.com	\N	\\x16c246198d91e0c3998f050866be46c72b21f9b8eb14a65c4e766f73037265eb	\N	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	\\x03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4	Caregiver	active	{0,4}	{EMAIL,SMS}	ASSIGNED_ONLY	\N	["HotBack"]	{}
fc0d0e36-cc08-4ba9-835e-6d9d7bbc6659	18842522-420e-467d-abc0-bfe91f320525	admin	\\x8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918	Admin	\N	\N	\N	\N	\\x9a4aabf0e5cf71cae2cea646613ce7e2a5919fa758e56819704be25a3a2c1f0b	\N	Admin	active	\N	\N	\N	\N	\N	{}
728f885e-5265-486f-b9e3-bb430a242220	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	c2	\\x9c0abe51c6e6655d81de2d044d4fb194931f058c0426c67c7285d8f5657ed64a	c2	c2@demo.com	\N	\\x6a156615f49c971b98dfd2bfcc549f3fe353feb332100b75d4ddb7e1646fe95f	\N	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	\\x03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4	Caregiver	active	{0,4}	{EMAIL,SMS}	ASSIGNED_ONLY	\N	["memoy"]	{}
8170063d-c22a-492a-a804-6f0cbaa95158	beefa852-9c2f-4641-8212-897d0f57c938	admin	\\x8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918	Admin	\N	\N	\N	\N	\\x9a4aabf0e5cf71cae2cea646613ce7e2a5919fa758e56819704be25a3a2c1f0b	\N	Admin	active	\N	\N	\N	2025-12-28 06:35:23.239121+00	\N	{}
c3b9bde2-4be4-4671-af81-f79694486932	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	c1	\\xd0f631ca1ddba8db3bcfcb9e057cdc98d0379f1bee00e75a545147a27dadd982	c1	c1@demo.com	\N	\\x2338ddd38d6f010cf89afc7a4538f1f2932bc5c2f0ca82284367f13bdf5d6803	\N	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	\\xcbfad02f9ed2a8d1e08d8f74f5303e9eb93637d47f82ab6f1c15871cf8dd0481	Caregiver	active	{0,4}	{EMAIL,SMS}	ASSIGNED_ONLY	2026-01-08 04:11:46.944151+00	["EastST", "NightShift"]	{}
6b589b3f-e0ad-46b2-88c4-434ad65081d9	bb045e6b-7bc2-4e59-af2e-d8b1adc77f2c	m1	\\xca0df2c95aa144c1d0ff2ff3c8f967fdc1de9ef0c4120b3726416701b519d619	m1	m1@demo.com	\N	\\x52bcb1d793f201ea5de410f51a6cd37eec271dbc48eacaad9730cbb1b73789a9	\N	\\x552691efde472982464368f31c2c7684ef4a8a25ce7911a4cb34ce802df5b2c0	\\x03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4	Manager	active	{0,4}	{EMAIL,SMS}	BRANCH	2026-01-08 04:36:38.442115+00	\N	{"vitalFocus": {"selectedCardIds": ["bcbfd775-fb5a-478a-bd78-3c0d369fbdd0", "212a89a1-48ee-4380-9354-f457b838c760", "8a3d2741-db16-41d5-ad12-37888a50f2ab"]}}
e0f23dda-ee49-4915-9d53-d23b2e5e045a	00000000-0000-0000-0000-000000000001	sysopr	\\xa02d9ea5f8f1bcb417508c135557f3a3ebb886af0de2605d680af7dc2010d55f	SystemOperator	\N	\N	\N	\N	\\x9a4aabf0e5cf71cae2cea646613ce7e2a5919fa758e56819704be25a3a2c1f0b	\N	SystemOperator	active	\N	\N	\N	2026-01-07 03:25:20.832742+00	\N	{}
\.


--
-- Name: iot_timeseries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.iot_timeseries_id_seq', 1, false);


--
-- Name: alarm_cloud alarm_cloud_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarm_cloud
    ADD CONSTRAINT alarm_cloud_pkey PRIMARY KEY (tenant_id);


--
-- Name: alarm_device alarm_device_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarm_device
    ADD CONSTRAINT alarm_device_pkey PRIMARY KEY (device_id);


--
-- Name: alarm_events alarm_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarm_events
    ADD CONSTRAINT alarm_events_pkey PRIMARY KEY (event_id);


--
-- Name: beds beds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_pkey PRIMARY KEY (bed_id);


--
-- Name: beds beds_tenant_id_room_id_bed_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_tenant_id_room_id_bed_name_key UNIQUE (tenant_id, room_id, bed_name);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (branch_id);


--
-- Name: buildings buildings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buildings
    ADD CONSTRAINT buildings_pkey PRIMARY KEY (building_id);


--
-- Name: cards cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_pkey PRIMARY KEY (card_id);


--
-- Name: config_versions config_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_versions
    ADD CONSTRAINT config_versions_pkey PRIMARY KEY (version_id);


--
-- Name: config_versions config_versions_tenant_id_config_type_entity_id_valid_from_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_versions
    ADD CONSTRAINT config_versions_tenant_id_config_type_entity_id_valid_from_key UNIQUE (tenant_id, config_type, entity_id, valid_from);


--
-- Name: device_store device_store_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_store
    ADD CONSTRAINT device_store_pkey PRIMARY KEY (device_store_id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (device_id);


--
-- Name: devices devices_tenant_id_serial_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_tenant_id_serial_number_key UNIQUE (tenant_id, serial_number);


--
-- Name: devices devices_tenant_id_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_tenant_id_uid_key UNIQUE (tenant_id, uid);


--
-- Name: resident_caregivers resident_caregivers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_caregivers
    ADD CONSTRAINT resident_caregivers_pkey PRIMARY KEY (caregiver_id);


--
-- Name: resident_caregivers resident_caregivers_tenant_id_resident_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_caregivers
    ADD CONSTRAINT resident_caregivers_tenant_id_resident_id_key UNIQUE (tenant_id, resident_id);


--
-- Name: resident_contacts resident_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_contacts
    ADD CONSTRAINT resident_contacts_pkey PRIMARY KEY (resident_id, slot);


--
-- Name: resident_contacts resident_contacts_tenant_id_resident_id_slot_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_contacts
    ADD CONSTRAINT resident_contacts_tenant_id_resident_id_slot_key UNIQUE (tenant_id, resident_id, slot);


--
-- Name: resident_phi resident_phi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_phi
    ADD CONSTRAINT resident_phi_pkey PRIMARY KEY (phi_id);


--
-- Name: resident_phi resident_phi_tenant_id_resident_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_phi
    ADD CONSTRAINT resident_phi_tenant_id_resident_id_key UNIQUE (tenant_id, resident_id);


--
-- Name: residents residents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_pkey PRIMARY KEY (resident_id);


--
-- Name: residents residents_tenant_id_nickname_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_tenant_id_nickname_key UNIQUE (tenant_id, nickname);


--
-- Name: residents residents_tenant_id_resident_account_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_tenant_id_resident_account_key UNIQUE (tenant_id, resident_account);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (permission_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (room_id);


--
-- Name: rooms rooms_tenant_id_unit_id_room_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_tenant_id_unit_id_room_name_key UNIQUE (tenant_id, unit_id, room_name);


--
-- Name: round_details round_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.round_details
    ADD CONSTRAINT round_details_pkey PRIMARY KEY (detail_id);


--
-- Name: round_details round_details_round_id_resident_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.round_details
    ADD CONSTRAINT round_details_round_id_resident_id_key UNIQUE (round_id, resident_id);


--
-- Name: rounds rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rounds
    ADD CONSTRAINT rounds_pkey PRIMARY KEY (round_id);


--
-- Name: service_levels service_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_levels
    ADD CONSTRAINT service_levels_pkey PRIMARY KEY (level_code);


--
-- Name: sleepace_report sleepace_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sleepace_report
    ADD CONSTRAINT sleepace_report_pkey PRIMARY KEY (report_id);


--
-- Name: sleepace_report sleepace_report_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sleepace_report
    ADD CONSTRAINT sleepace_report_unique UNIQUE (tenant_id, device_id, date);


--
-- Name: snomed_mapping snomed_mapping_mapping_type_source_value_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.snomed_mapping
    ADD CONSTRAINT snomed_mapping_mapping_type_source_value_key UNIQUE (mapping_type, source_value);


--
-- Name: snomed_mapping snomed_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.snomed_mapping
    ADD CONSTRAINT snomed_mapping_pkey PRIMARY KEY (mapping_id);


--
-- Name: tenants tenants_domain_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_domain_key UNIQUE (domain);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (tenant_id);


--
-- Name: units units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_pkey PRIMARY KEY (unit_id, tenant_id);


--
-- Name: branches uq_branches_branch_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT uq_branches_branch_id UNIQUE (branch_id);


--
-- Name: buildings uq_buildings_building_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buildings
    ADD CONSTRAINT uq_buildings_building_id UNIQUE (building_id);


--
-- Name: units uq_units_unit_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT uq_units_unit_id UNIQUE (unit_id);


--
-- Name: user_branches user_branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_pkey PRIMARY KEY (user_branch_id);


--
-- Name: user_branches user_branches_tenant_id_user_id_branch_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_tenant_id_user_id_branch_id_key UNIQUE (tenant_id, user_id, branch_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_tenant_id_user_account_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_user_account_key UNIQUE (tenant_id, user_account);


--
-- Name: idx_alarm_cloud_device_alarms; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_cloud_device_alarms ON public.alarm_cloud USING gin (device_alarms);


--
-- Name: idx_alarm_device_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_device_device ON public.alarm_device USING btree (tenant_id, device_id);


--
-- Name: idx_alarm_device_monitor_config; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_device_monitor_config ON public.alarm_device USING gin (monitor_config) WHERE (monitor_config IS NOT NULL);


--
-- Name: idx_alarm_device_vendor_config; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_device_vendor_config ON public.alarm_device USING gin (vendor_config) WHERE (vendor_config IS NOT NULL);


--
-- Name: idx_alarm_events_alarm_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_events_alarm_level ON public.alarm_events USING btree (tenant_id, alarm_level, triggered_at DESC);


--
-- Name: idx_alarm_events_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_events_category ON public.alarm_events USING btree (tenant_id, category, triggered_at DESC) WHERE (category IS NOT NULL);


--
-- Name: idx_alarm_events_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_events_device ON public.alarm_events USING btree (tenant_id, device_id, triggered_at DESC);


--
-- Name: idx_alarm_events_handler; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_events_handler ON public.alarm_events USING btree (tenant_id, handler, triggered_at DESC) WHERE (handler IS NOT NULL);


--
-- Name: idx_alarm_events_informational; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_events_informational ON public.alarm_events USING btree (tenant_id, alarm_level, triggered_at DESC) WHERE ((alarm_level)::text = ANY ((ARRAY['6'::character varying, 'INFO'::character varying, '7'::character varying, 'DEBUG'::character varying])::text[]));


--
-- Name: idx_alarm_events_iot_timeseries_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_events_iot_timeseries_id ON public.alarm_events USING btree (tenant_id, iot_timeseries_id, triggered_at DESC) WHERE (iot_timeseries_id IS NOT NULL);


--
-- Name: idx_alarm_events_operation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_events_operation ON public.alarm_events USING btree (tenant_id, operation, hand_time DESC) WHERE (operation IS NOT NULL);


--
-- Name: idx_alarm_events_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_events_status ON public.alarm_events USING btree (tenant_id, alarm_status, triggered_at DESC) WHERE (((alarm_status)::text = ANY ((ARRAY['active'::character varying, 'acknowledged'::character varying])::text[])) AND ((alarm_level)::text <> ALL ((ARRAY['6'::character varying, 'INFO'::character varying, '7'::character varying, 'DEBUG'::character varying])::text[])));


--
-- Name: idx_alarm_events_triggered_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_events_triggered_at ON public.alarm_events USING btree (tenant_id, triggered_at DESC);


--
-- Name: idx_alarm_events_type_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alarm_events_type_level ON public.alarm_events USING btree (tenant_id, event_type, alarm_level, triggered_at DESC);


--
-- Name: idx_beds_room_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_beds_room_id ON public.beds USING btree (tenant_id, room_id);


--
-- Name: idx_beds_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_beds_tenant ON public.beds USING btree (tenant_id);


--
-- Name: idx_branches_branch_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_branches_branch_name ON public.branches USING btree (tenant_id, branch_name);


--
-- Name: idx_branches_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_branches_tenant ON public.branches USING btree (tenant_id);


--
-- Name: idx_branches_unique_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_branches_unique_name ON public.branches USING btree (tenant_id, branch_name);


--
-- Name: idx_buildings_branch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_buildings_branch_id ON public.buildings USING btree (tenant_id, branch_id) WHERE (branch_id IS NOT NULL);


--
-- Name: idx_buildings_building_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_buildings_building_name ON public.buildings USING btree (tenant_id, building_name);


--
-- Name: idx_buildings_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_buildings_tenant ON public.buildings USING btree (tenant_id);


--
-- Name: idx_buildings_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_buildings_unique ON public.buildings USING btree (tenant_id, branch_id, building_name);


--
-- Name: idx_cards_bed_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cards_bed_id ON public.cards USING btree (tenant_id, bed_id) WHERE (bed_id IS NOT NULL);


--
-- Name: idx_cards_devices; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cards_devices ON public.cards USING gin (devices) WHERE (jsonb_array_length(devices) > 0);


--
-- Name: idx_cards_resident_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cards_resident_id ON public.cards USING btree (tenant_id, resident_id) WHERE (resident_id IS NOT NULL);


--
-- Name: idx_cards_residents; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cards_residents ON public.cards USING gin (residents) WHERE (jsonb_array_length(residents) > 0);


--
-- Name: idx_cards_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cards_tenant ON public.cards USING btree (tenant_id);


--
-- Name: idx_cards_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cards_type ON public.cards USING btree (tenant_id, card_type);


--
-- Name: idx_cards_unhandled_alarms; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cards_unhandled_alarms ON public.cards USING btree (tenant_id, (((((unhandled_alarm_0 + unhandled_alarm_1) + unhandled_alarm_2) + unhandled_alarm_3) + unhandled_alarm_4))) WHERE (((((unhandled_alarm_0 + unhandled_alarm_1) + unhandled_alarm_2) + unhandled_alarm_3) + unhandled_alarm_4) > 0);


--
-- Name: idx_cards_unit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cards_unit_id ON public.cards USING btree (tenant_id, unit_id) WHERE (unit_id IS NOT NULL);


--
-- Name: idx_config_versions_config_data; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_versions_config_data ON public.config_versions USING gin (config_data);


--
-- Name: idx_config_versions_current_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_versions_current_entity ON public.config_versions USING btree (current_entity_id) WHERE (current_entity_id IS NOT NULL);


--
-- Name: idx_config_versions_tenant_type_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_versions_tenant_type_entity ON public.config_versions USING btree (tenant_id, config_type, entity_id);


--
-- Name: idx_config_versions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_versions_type ON public.config_versions USING btree (tenant_id, config_type, valid_from DESC);


--
-- Name: idx_config_versions_valid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_versions_valid ON public.config_versions USING btree (tenant_id, config_type, entity_id, valid_from, valid_to);


--
-- Name: idx_device_store_allocate_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_store_allocate_time ON public.device_store USING btree (allocate_time) WHERE (allocate_time IS NOT NULL);


--
-- Name: idx_device_store_allow_access; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_store_allow_access ON public.device_store USING btree (tenant_id, allow_access) WHERE (allow_access = true);


--
-- Name: idx_device_store_device_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_store_device_type ON public.device_store USING btree (device_type);


--
-- Name: idx_device_store_firmware_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_store_firmware_version ON public.device_store USING btree (firmware_version) WHERE (firmware_version IS NOT NULL);


--
-- Name: idx_device_store_import_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_store_import_date ON public.device_store USING btree (import_date);


--
-- Name: idx_device_store_ota_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_store_ota_target ON public.device_store USING btree (ota_target_firmware_version) WHERE (ota_target_firmware_version IS NOT NULL);


--
-- Name: idx_device_store_serial; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_store_serial ON public.device_store USING btree (serial_number) WHERE (serial_number IS NOT NULL);


--
-- Name: idx_device_store_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_store_tenant_id ON public.device_store USING btree (tenant_id);


--
-- Name: idx_device_store_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_store_uid ON public.device_store USING btree (uid) WHERE (uid IS NOT NULL);


--
-- Name: idx_device_store_unassigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_store_unassigned ON public.device_store USING btree (tenant_id) WHERE (tenant_id = '00000000-0000-0000-0000-000000000000'::uuid);


--
-- Name: idx_devices_bed_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_bed_id ON public.devices USING btree (tenant_id, bound_bed_id) WHERE (bound_bed_id IS NOT NULL);


--
-- Name: idx_devices_business_access_approved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_business_access_approved ON public.devices USING btree (tenant_id, business_access) WHERE ((business_access)::text = 'approved'::text);


--
-- Name: idx_devices_business_access_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_business_access_pending ON public.devices USING btree (tenant_id, business_access) WHERE ((business_access)::text = 'pending'::text);


--
-- Name: idx_devices_device_store_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_device_store_id ON public.devices USING btree (device_store_id) WHERE (device_store_id IS NOT NULL);


--
-- Name: idx_devices_monitoring; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_monitoring ON public.devices USING btree (tenant_id, monitoring_enabled) WHERE (monitoring_enabled = true);


--
-- Name: idx_devices_room_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_room_id ON public.devices USING btree (tenant_id, bound_room_id) WHERE (bound_room_id IS NOT NULL);


--
-- Name: idx_devices_serial; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_serial ON public.devices USING btree (tenant_id, serial_number);


--
-- Name: idx_devices_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_status ON public.devices USING btree (tenant_id, status) WHERE ((status)::text <> 'disabled'::text);


--
-- Name: idx_devices_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_tenant_id ON public.devices USING btree (tenant_id);


--
-- Name: idx_iot_timeseries_alarm_event; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_alarm_event ON public.iot_timeseries USING btree (tenant_id, alarm_event_id, "timestamp" DESC) WHERE (alarm_event_id IS NOT NULL);


--
-- Name: idx_iot_timeseries_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_category ON public.iot_timeseries USING btree (tenant_id, device_id, category, "timestamp" DESC);


--
-- Name: idx_iot_timeseries_data_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_data_type ON public.iot_timeseries USING btree (tenant_id, device_id, data_type, "timestamp" DESC);


--
-- Name: idx_iot_timeseries_device_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_device_model ON public.iot_timeseries USING btree (tenant_id, device_model, "timestamp" DESC) WHERE (device_model IS NOT NULL);


--
-- Name: idx_iot_timeseries_device_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_device_type ON public.iot_timeseries USING btree (tenant_id, device_type, "timestamp" DESC) WHERE (device_type IS NOT NULL);


--
-- Name: idx_iot_timeseries_event_snomed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_event_snomed ON public.iot_timeseries USING btree (tenant_id, device_id, event_snomed_code, "timestamp" DESC) WHERE (event_snomed_code IS NOT NULL);


--
-- Name: idx_iot_timeseries_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_event_type ON public.iot_timeseries USING btree (tenant_id, device_id, event_type, "timestamp" DESC);


--
-- Name: idx_iot_timeseries_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_location ON public.iot_timeseries USING btree (tenant_id, unit_id, "timestamp" DESC) WHERE (unit_id IS NOT NULL);


--
-- Name: idx_iot_timeseries_posture_snomed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_posture_snomed ON public.iot_timeseries USING btree (tenant_id, device_id, posture_snomed_code, "timestamp" DESC);


--
-- Name: idx_iot_timeseries_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_room ON public.iot_timeseries USING btree (tenant_id, room_id, "timestamp" DESC) WHERE (room_id IS NOT NULL);


--
-- Name: idx_iot_timeseries_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_serial_number ON public.iot_timeseries USING btree (tenant_id, serial_number, "timestamp" DESC) WHERE (serial_number IS NOT NULL);


--
-- Name: idx_iot_timeseries_sleep_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_sleep_state ON public.iot_timeseries USING btree (tenant_id, device_id, sleep_state_snomed_code, "timestamp" DESC) WHERE (sleep_state_snomed_code IS NOT NULL);


--
-- Name: idx_iot_timeseries_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_timestamp ON public.iot_timeseries USING btree (tenant_id, device_id, "timestamp" DESC);


--
-- Name: idx_iot_timeseries_tracking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_tracking_id ON public.iot_timeseries USING btree (tenant_id, device_id, tracking_id, "timestamp" DESC);


--
-- Name: idx_iot_timeseries_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_uid ON public.iot_timeseries USING btree (tenant_id, uid, "timestamp" DESC) WHERE (uid IS NOT NULL);


--
-- Name: idx_iot_timeseries_vital_signs; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iot_timeseries_vital_signs ON public.iot_timeseries USING btree (tenant_id, device_id, heart_rate, respiratory_rate, "timestamp" DESC) WHERE ((heart_rate IS NOT NULL) OR (respiratory_rate IS NOT NULL));


--
-- Name: idx_resident_caregivers_group_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resident_caregivers_group_list ON public.resident_caregivers USING gin (group_list) WHERE (group_list IS NOT NULL);


--
-- Name: idx_resident_caregivers_resident; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resident_caregivers_resident ON public.resident_caregivers USING btree (resident_id);


--
-- Name: idx_resident_caregivers_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resident_caregivers_tenant ON public.resident_caregivers USING btree (tenant_id, resident_id);


--
-- Name: idx_resident_caregivers_user_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resident_caregivers_user_list ON public.resident_caregivers USING gin (user_list) WHERE (user_list IS NOT NULL);


--
-- Name: idx_resident_contacts_resident; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resident_contacts_resident ON public.resident_contacts USING btree (resident_id);


--
-- Name: idx_resident_contacts_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resident_contacts_tenant ON public.resident_contacts USING btree (tenant_id, resident_id);


--
-- Name: idx_resident_phi_resident; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resident_phi_resident ON public.resident_phi USING btree (resident_id);


--
-- Name: idx_resident_phi_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resident_phi_tenant ON public.resident_phi USING btree (tenant_id);


--
-- Name: idx_residents_branch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residents_branch_id ON public.residents USING btree (tenant_id, branch_id) WHERE (branch_id IS NOT NULL);


--
-- Name: idx_residents_email_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residents_email_hash ON public.residents USING btree (email_hash) WHERE (email_hash IS NOT NULL);


--
-- Name: idx_residents_nickname; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residents_nickname ON public.residents USING btree (tenant_id, nickname);


--
-- Name: idx_residents_phone_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residents_phone_hash ON public.residents USING btree (phone_hash) WHERE (phone_hash IS NOT NULL);


--
-- Name: idx_residents_service_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residents_service_level ON public.residents USING btree (tenant_id, service_level) WHERE (service_level IS NOT NULL);


--
-- Name: idx_residents_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residents_status ON public.residents USING btree (tenant_id, status);


--
-- Name: idx_residents_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residents_tenant_id ON public.residents USING btree (tenant_id);


--
-- Name: idx_residents_unit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_residents_unit_id ON public.residents USING btree (tenant_id, unit_id) WHERE (unit_id IS NOT NULL);


--
-- Name: idx_role_permissions_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_permissions_resource ON public.role_permissions USING btree (resource_type, permission_type);


--
-- Name: idx_role_permissions_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_permissions_role ON public.role_permissions USING btree (role_code);


--
-- Name: idx_role_permissions_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_permissions_tenant ON public.role_permissions USING btree (tenant_id, role_code);


--
-- Name: idx_roles_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_roles_active ON public.roles USING btree (tenant_id, is_active) WHERE (is_active = true);


--
-- Name: idx_roles_system; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_roles_system ON public.roles USING btree (is_system) WHERE (is_system = true);


--
-- Name: idx_roles_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_roles_tenant_id ON public.roles USING btree (tenant_id, is_active);


--
-- Name: idx_rooms_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rooms_tenant ON public.rooms USING btree (tenant_id);


--
-- Name: idx_rooms_unit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rooms_unit_id ON public.rooms USING btree (tenant_id, unit_id);


--
-- Name: idx_round_details_bed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_round_details_bed ON public.round_details USING btree (tenant_id, bed_id) WHERE (bed_id IS NOT NULL);


--
-- Name: idx_round_details_bed_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_round_details_bed_status ON public.round_details USING btree (bed_status) WHERE (bed_status IS NOT NULL);


--
-- Name: idx_round_details_resident; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_round_details_resident ON public.round_details USING btree (tenant_id, resident_id);


--
-- Name: idx_round_details_round; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_round_details_round ON public.round_details USING btree (round_id);


--
-- Name: idx_round_details_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_round_details_tenant ON public.round_details USING btree (tenant_id);


--
-- Name: idx_round_details_unit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_round_details_unit ON public.round_details USING btree (tenant_id, unit_id) WHERE (unit_id IS NOT NULL);


--
-- Name: idx_rounds_executor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rounds_executor ON public.rounds USING btree (tenant_id, executor_id, round_time DESC);


--
-- Name: idx_rounds_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rounds_status ON public.rounds USING btree (tenant_id, status) WHERE ((status)::text = 'completed'::text);


--
-- Name: idx_rounds_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rounds_tenant ON public.rounds USING btree (tenant_id, round_time DESC);


--
-- Name: idx_rounds_unit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rounds_unit ON public.rounds USING btree (tenant_id, unit_id, round_time DESC) WHERE (unit_id IS NOT NULL);


--
-- Name: idx_service_levels_color; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_levels_color ON public.service_levels USING btree (color);


--
-- Name: idx_service_levels_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_levels_priority ON public.service_levels USING btree (priority);


--
-- Name: idx_sleepace_report_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sleepace_report_date ON public.sleepace_report USING btree (date);


--
-- Name: idx_sleepace_report_device_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sleepace_report_device_code ON public.sleepace_report USING btree (tenant_id, device_code);


--
-- Name: idx_sleepace_report_device_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sleepace_report_device_date ON public.sleepace_report USING btree (device_id, date);


--
-- Name: idx_sleepace_report_tenant_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sleepace_report_tenant_device ON public.sleepace_report USING btree (tenant_id, device_id);


--
-- Name: idx_snomed_mapping_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_snomed_mapping_category ON public.snomed_mapping USING btree (category);


--
-- Name: idx_snomed_mapping_snomed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_snomed_mapping_snomed ON public.snomed_mapping USING btree (snomed_code) WHERE (snomed_code IS NOT NULL);


--
-- Name: idx_snomed_mapping_type_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_snomed_mapping_type_source ON public.snomed_mapping USING btree (mapping_type, source_value);


--
-- Name: idx_tenants_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_domain ON public.tenants USING btree (domain);


--
-- Name: idx_tenants_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_status ON public.tenants USING btree (status);


--
-- Name: idx_tenants_tenant_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_tenant_type ON public.tenants USING btree (tenant_type);


--
-- Name: idx_units_branch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_units_branch_id ON public.units USING btree (tenant_id, branch_id) WHERE (branch_id IS NOT NULL);


--
-- Name: idx_units_building_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_units_building_id ON public.units USING btree (tenant_id, building_id) WHERE (building_id IS NOT NULL);


--
-- Name: idx_units_floor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_units_floor ON public.units USING btree (tenant_id, floor);


--
-- Name: idx_units_public; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_units_public ON public.units USING btree (tenant_id, is_public) WHERE (is_public = true);


--
-- Name: idx_units_shared_unit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_units_shared_unit ON public.units USING btree (tenant_id, is_shared_unit) WHERE (is_shared_unit = true);


--
-- Name: idx_units_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_units_tenant ON public.units USING btree (tenant_id);


--
-- Name: idx_units_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_units_unique ON public.units USING btree (tenant_id, branch_id, building_id, floor, unit_name);


--
-- Name: idx_units_unit_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_units_unit_name ON public.units USING btree (tenant_id, unit_name);


--
-- Name: idx_user_branches_branch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_branches_branch ON public.user_branches USING btree (tenant_id, branch_id);


--
-- Name: idx_user_branches_one_primary; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_branches_one_primary ON public.user_branches USING btree (tenant_id, user_id) WHERE (is_primary = true);


--
-- Name: idx_user_branches_primary; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_branches_primary ON public.user_branches USING btree (tenant_id, user_id, is_primary) WHERE (is_primary = true);


--
-- Name: idx_user_branches_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_branches_tenant ON public.user_branches USING btree (tenant_id);


--
-- Name: idx_user_branches_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_branches_user ON public.user_branches USING btree (tenant_id, user_id);


--
-- Name: idx_users_email_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email_hash ON public.users USING btree (email_hash) WHERE (email_hash IS NOT NULL);


--
-- Name: idx_users_phone_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_phone_hash ON public.users USING btree (phone_hash) WHERE (phone_hash IS NOT NULL);


--
-- Name: idx_users_preferences; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_preferences ON public.users USING gin (preferences) WHERE (preferences IS NOT NULL);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_role ON public.users USING btree (tenant_id, role);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_status ON public.users USING btree (tenant_id, status);


--
-- Name: idx_users_tenant_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_users_tenant_email_unique ON public.users USING btree (tenant_id, email) WHERE (email IS NOT NULL);


--
-- Name: idx_users_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: idx_users_tenant_phone_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_users_tenant_phone_unique ON public.users USING btree (tenant_id, phone) WHERE (phone IS NOT NULL);


--
-- Name: idx_users_user_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_user_account ON public.users USING btree (tenant_id, user_account);


--
-- Name: ux_cards_activebed_bed; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_cards_activebed_bed ON public.cards USING btree (tenant_id, bed_id) WHERE (((card_type)::text = 'ActiveBed'::text) AND (bed_id IS NOT NULL));


--
-- Name: ux_cards_location_unit; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_cards_location_unit ON public.cards USING btree (tenant_id, unit_id) WHERE (((card_type)::text = 'Location'::text) AND (unit_id IS NOT NULL));


--
-- Name: ux_device_store_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_device_store_serial_number ON public.device_store USING btree (serial_number) WHERE (serial_number IS NOT NULL);


--
-- Name: ux_device_store_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_device_store_uid ON public.device_store USING btree (uid) WHERE (uid IS NOT NULL);


--
-- Name: ux_role_permissions_tenant_role_resource_perm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_role_permissions_tenant_role_resource_perm ON public.role_permissions USING btree (COALESCE(tenant_id, '00000000-0000-0000-0000-000000000000'::uuid), role_code, resource_type, permission_type);


--
-- Name: ux_roles_tenant_role_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_roles_tenant_role_code ON public.roles USING btree (COALESCE(tenant_id, '00000000-0000-0000-0000-000000000000'::uuid), role_code);


--
-- Name: residents trigger_residents_lowercase_account; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_residents_lowercase_account BEFORE INSERT OR UPDATE ON public.residents FOR EACH ROW WHEN ((new.resident_account IS NOT NULL)) EXECUTE FUNCTION public.ensure_lowercase_resident_account();


--
-- Name: alarm_events trigger_update_alarm_events_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_alarm_events_updated_at BEFORE UPDATE ON public.alarm_events FOR EACH ROW EXECUTE FUNCTION public.update_alarm_events_updated_at();


--
-- Name: users trigger_users_lowercase_account; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_users_lowercase_account BEFORE INSERT OR UPDATE ON public.users FOR EACH ROW WHEN ((new.user_account IS NOT NULL)) EXECUTE FUNCTION public.ensure_lowercase_user_account();


--
-- Name: beds trigger_validate_bed_tenant; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_bed_tenant BEFORE INSERT OR UPDATE OF room_id, tenant_id ON public.beds FOR EACH ROW EXECUTE FUNCTION public.validate_bed_tenant();


--
-- Name: cards trigger_validate_card_bed_unit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_card_bed_unit BEFORE INSERT OR UPDATE OF bed_id, unit_id ON public.cards FOR EACH ROW EXECUTE FUNCTION public.validate_card_bed_unit();


--
-- Name: cards trigger_validate_card_resident_bed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_card_resident_bed BEFORE INSERT OR UPDATE OF resident_id, bed_id ON public.cards FOR EACH ROW EXECUTE FUNCTION public.validate_card_resident_bed();


--
-- Name: cards trigger_validate_card_tenant; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_card_tenant BEFORE INSERT OR UPDATE OF bed_id, unit_id, resident_id, tenant_id ON public.cards FOR EACH ROW EXECUTE FUNCTION public.validate_card_tenant();


--
-- Name: devices trigger_validate_device_bed_room; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_device_bed_room BEFORE INSERT OR UPDATE OF bound_bed_id, bound_room_id ON public.devices FOR EACH ROW EXECUTE FUNCTION public.validate_device_bed_room();


--
-- Name: devices trigger_validate_device_bed_tenant; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_device_bed_tenant BEFORE INSERT OR UPDATE OF bound_bed_id, bound_room_id, tenant_id ON public.devices FOR EACH ROW EXECUTE FUNCTION public.validate_device_bed_tenant();


--
-- Name: devices trigger_validate_device_identifier; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_device_identifier BEFORE INSERT OR UPDATE OF serial_number, uid ON public.devices FOR EACH ROW EXECUTE FUNCTION public.validate_device_identifier();


--
-- Name: devices trigger_validate_device_store_tenant; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_device_store_tenant BEFORE INSERT OR UPDATE OF device_store_id, tenant_id ON public.devices FOR EACH ROW EXECUTE FUNCTION public.validate_device_store_tenant();


--
-- Name: iot_timeseries trigger_validate_iot_timeseries_location_device; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_iot_timeseries_location_device BEFORE INSERT OR UPDATE OF unit_id, room_id, device_id ON public.iot_timeseries FOR EACH ROW EXECUTE FUNCTION public.validate_iot_timeseries_location_device();


--
-- Name: iot_timeseries trigger_validate_iot_timeseries_location_tenant; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_iot_timeseries_location_tenant BEFORE INSERT OR UPDATE OF unit_id, room_id, tenant_id ON public.iot_timeseries FOR EACH ROW EXECUTE FUNCTION public.validate_iot_timeseries_location_tenant();


--
-- Name: residents trigger_validate_resident_bed_room; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_resident_bed_room BEFORE INSERT OR UPDATE OF bed_id, room_id ON public.residents FOR EACH ROW EXECUTE FUNCTION public.validate_resident_bed_room();


--
-- Name: resident_caregivers trigger_validate_resident_caregiver_tenant; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_resident_caregiver_tenant BEFORE INSERT OR UPDATE OF resident_id, tenant_id, group_list, user_list ON public.resident_caregivers FOR EACH ROW EXECUTE FUNCTION public.validate_resident_caregiver_tenant();


--
-- Name: residents trigger_validate_resident_location_hierarchy; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_resident_location_hierarchy BEFORE INSERT OR UPDATE OF unit_id, room_id, bed_id ON public.residents FOR EACH ROW EXECUTE FUNCTION public.validate_resident_location_hierarchy();


--
-- Name: residents trigger_validate_resident_location_tenant; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_resident_location_tenant BEFORE INSERT OR UPDATE OF unit_id, room_id, bed_id, tenant_id ON public.residents FOR EACH ROW EXECUTE FUNCTION public.validate_resident_location_tenant();


--
-- Name: residents trigger_validate_resident_room_unit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_resident_room_unit BEFORE INSERT OR UPDATE OF room_id, unit_id ON public.residents FOR EACH ROW EXECUTE FUNCTION public.validate_resident_room_unit();


--
-- Name: rooms trigger_validate_room_tenant; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_validate_room_tenant BEFORE INSERT OR UPDATE OF unit_id, tenant_id ON public.rooms FOR EACH ROW EXECUTE FUNCTION public.validate_room_tenant();


--
-- Name: alarm_cloud alarm_cloud_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarm_cloud
    ADD CONSTRAINT alarm_cloud_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: alarm_device alarm_device_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarm_device
    ADD CONSTRAINT alarm_device_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id) ON DELETE CASCADE;


--
-- Name: alarm_device alarm_device_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarm_device
    ADD CONSTRAINT alarm_device_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: alarm_events alarm_events_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarm_events
    ADD CONSTRAINT alarm_events_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id) ON DELETE CASCADE;


--
-- Name: alarm_events alarm_events_handler_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarm_events
    ADD CONSTRAINT alarm_events_handler_fkey FOREIGN KEY (handler) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: alarm_events alarm_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alarm_events
    ADD CONSTRAINT alarm_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: beds beds_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(room_id) ON DELETE CASCADE;


--
-- Name: beds beds_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.beds
    ADD CONSTRAINT beds_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: branches branches_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: buildings buildings_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buildings
    ADD CONSTRAINT buildings_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(branch_id) ON DELETE RESTRICT;


--
-- Name: buildings buildings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buildings
    ADD CONSTRAINT buildings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: cards cards_bed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_bed_id_fkey FOREIGN KEY (bed_id) REFERENCES public.beds(bed_id) ON DELETE CASCADE;


--
-- Name: cards cards_resident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_resident_id_fkey FOREIGN KEY (resident_id) REFERENCES public.residents(resident_id) ON DELETE SET NULL;


--
-- Name: cards cards_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: cards cards_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(unit_id) ON DELETE CASCADE;


--
-- Name: config_versions config_versions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_versions
    ADD CONSTRAINT config_versions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: devices devices_bound_bed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_bound_bed_id_fkey FOREIGN KEY (bound_bed_id) REFERENCES public.beds(bed_id) ON DELETE SET NULL;


--
-- Name: devices devices_bound_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_bound_room_id_fkey FOREIGN KEY (bound_room_id) REFERENCES public.rooms(room_id) ON DELETE SET NULL;


--
-- Name: devices devices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: iot_timeseries fk_iot_timeseries_alarm_event; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iot_timeseries
    ADD CONSTRAINT fk_iot_timeseries_alarm_event FOREIGN KEY (alarm_event_id) REFERENCES public.alarm_events(event_id) ON DELETE SET NULL;


--
-- Name: iot_timeseries iot_timeseries_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iot_timeseries
    ADD CONSTRAINT iot_timeseries_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id) ON DELETE CASCADE;


--
-- Name: iot_timeseries iot_timeseries_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iot_timeseries
    ADD CONSTRAINT iot_timeseries_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(room_id) ON DELETE SET NULL;


--
-- Name: iot_timeseries iot_timeseries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iot_timeseries
    ADD CONSTRAINT iot_timeseries_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: iot_timeseries iot_timeseries_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iot_timeseries
    ADD CONSTRAINT iot_timeseries_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(unit_id) ON DELETE SET NULL;


--
-- Name: resident_caregivers resident_caregivers_resident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_caregivers
    ADD CONSTRAINT resident_caregivers_resident_id_fkey FOREIGN KEY (resident_id) REFERENCES public.residents(resident_id) ON DELETE CASCADE;


--
-- Name: resident_caregivers resident_caregivers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_caregivers
    ADD CONSTRAINT resident_caregivers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: resident_contacts resident_contacts_resident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_contacts
    ADD CONSTRAINT resident_contacts_resident_id_fkey FOREIGN KEY (resident_id) REFERENCES public.residents(resident_id) ON DELETE CASCADE;


--
-- Name: resident_contacts resident_contacts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_contacts
    ADD CONSTRAINT resident_contacts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: resident_phi resident_phi_resident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_phi
    ADD CONSTRAINT resident_phi_resident_id_fkey FOREIGN KEY (resident_id) REFERENCES public.residents(resident_id) ON DELETE CASCADE;


--
-- Name: resident_phi resident_phi_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resident_phi
    ADD CONSTRAINT resident_phi_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: residents residents_bed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_bed_id_fkey FOREIGN KEY (bed_id) REFERENCES public.beds(bed_id) ON DELETE SET NULL;


--
-- Name: residents residents_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(branch_id) ON DELETE SET NULL;


--
-- Name: residents residents_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(room_id) ON DELETE SET NULL;


--
-- Name: residents residents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: residents residents_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.residents
    ADD CONSTRAINT residents_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(unit_id) ON DELETE SET NULL;


--
-- Name: role_permissions role_permissions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: roles roles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: rooms rooms_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: rooms rooms_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(unit_id) ON DELETE CASCADE;


--
-- Name: round_details round_details_bed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.round_details
    ADD CONSTRAINT round_details_bed_id_fkey FOREIGN KEY (bed_id) REFERENCES public.beds(bed_id) ON DELETE SET NULL;


--
-- Name: round_details round_details_resident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.round_details
    ADD CONSTRAINT round_details_resident_id_fkey FOREIGN KEY (resident_id) REFERENCES public.residents(resident_id) ON DELETE CASCADE;


--
-- Name: round_details round_details_round_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.round_details
    ADD CONSTRAINT round_details_round_id_fkey FOREIGN KEY (round_id) REFERENCES public.rounds(round_id) ON DELETE CASCADE;


--
-- Name: round_details round_details_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.round_details
    ADD CONSTRAINT round_details_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: round_details round_details_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.round_details
    ADD CONSTRAINT round_details_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(unit_id) ON DELETE SET NULL;


--
-- Name: rounds rounds_executor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rounds
    ADD CONSTRAINT rounds_executor_id_fkey FOREIGN KEY (executor_id) REFERENCES public.users(user_id) ON DELETE RESTRICT;


--
-- Name: rounds rounds_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rounds
    ADD CONSTRAINT rounds_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: rounds rounds_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rounds
    ADD CONSTRAINT rounds_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(unit_id) ON DELETE SET NULL;


--
-- Name: sleepace_report sleepace_report_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sleepace_report
    ADD CONSTRAINT sleepace_report_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(device_id) ON DELETE CASCADE;


--
-- Name: sleepace_report sleepace_report_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sleepace_report
    ADD CONSTRAINT sleepace_report_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: units units_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(branch_id) ON DELETE RESTRICT;


--
-- Name: units units_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(building_id) ON DELETE SET NULL;


--
-- Name: units units_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: user_branches user_branches_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(branch_id) ON DELETE CASCADE;


--
-- Name: user_branches user_branches_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- Name: user_branches user_branches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict fHKF4WJpX0gNBjnBP4SZGesWe9nenpNAxm4xYQxglVcs5xrsCBA6jYWhFYnbs1M

